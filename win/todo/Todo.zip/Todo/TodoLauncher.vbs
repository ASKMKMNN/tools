Option Explicit

Dim fso, shell, scriptDir, ps1Path, logPath, cmd, lf

Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1Path   = fso.BuildPath(scriptDir, "TodoCore.ps1")
logPath   = fso.BuildPath(scriptDir, "launcher.log")

On Error Resume Next
Set lf = fso.OpenTextFile(logPath, 8, True)
lf.WriteLine "----------------------------------------"
lf.WriteLine Now & "  Launcher start"
lf.WriteLine "  scriptDir = " & scriptDir
lf.WriteLine "  ps1Path   = " & ps1Path
lf.WriteLine "  ps1 exists = " & fso.FileExists(ps1Path)
On Error GoTo 0

If Not fso.FileExists(ps1Path) Then
    If Not lf Is Nothing Then
        lf.WriteLine "  !!! ps1 not found, exit"
        lf.Close
    End If
    MsgBox "TodoCore.ps1 not found:" & vbCrLf & ps1Path, 16, "Todo Launcher"
    WScript.Quit 1
End If

cmd = "powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -File """ & ps1Path & """"
If Not lf Is Nothing Then
    lf.WriteLine "  exec: " & cmd
    lf.Close
End If

shell.Run cmd, 0, False