﻿﻿# ============================================================
# 0. 日志系统（必须在最前面）
# ============================================================
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $scriptDir) { $scriptDir = (Get-Location).Path }
$global:scriptDir = $scriptDir
$global:logFile   = Join-Path $scriptDir "log.txt"

try { Remove-Item $global:logFile -Force -ErrorAction SilentlyContinue } catch {}

# ★ 关键：用 function global: 前缀定义
function global:Log {
    param([string]$msg)
    try {
        $ts = Get-Date -Format "HH:mm:ss.fff"
        [System.IO.File]::AppendAllText($global:logFile, "$ts  $msg`r`n", [System.Text.Encoding]::UTF8)
    } catch {}
}

Log "================================"
# 启动时自动备份脚本自身（内容变化才备份）
try {
    $selfBkDir = Join-Path $scriptDir "_backups"
    if (-not (Test-Path $selfBkDir)) { New-Item -ItemType Directory -Path $selfBkDir -Force | Out-Null }
    $curHash = (Get-FileHash $MyInvocation.MyCommand.Definition -Algorithm MD5).Hash
    $latestBk = Get-ChildItem $selfBkDir -Filter "TodoCore.ps1.bak_*" -File -ErrorAction SilentlyContinue |
                Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $needBk = $true
    if ($latestBk) {
        $latestHash = (Get-FileHash $latestBk.FullName -Algorithm MD5).Hash
        if ($latestHash -eq $curHash) { $needBk = $false }
    }
    if ($needBk) {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $selfBk = Join-Path $selfBkDir "TodoCore.ps1.bak_$stamp"
        Copy-Item $MyInvocation.MyCommand.Definition $selfBk -Force
        Get-ChildItem $selfBkDir -Filter "TodoCore.ps1.bak_*" -File |
            Sort-Object LastWriteTime -Descending |
            Select-Object -Skip 20 |
            Remove-Item -Force -ErrorAction SilentlyContinue
    }
} catch {}

Log "启动 Todo/Noty 脚本"
Log "PowerShell 版本: $($PSVersionTable.PSVersion)"
Log "ScriptDir: $scriptDir"

# ★ trap 块里不调用 Log 函数，改为内联写日志（最可靠）
trap {
    try {
        $ts = Get-Date -Format "HH:mm:ss.fff"
        [System.IO.File]::AppendAllText($global:logFile, "$ts  !!! TRAP: $($_.Exception.Message)`r`n", [System.Text.Encoding]::UTF8)
        [System.IO.File]::AppendAllText($global:logFile, "$ts  !!! 位置: $($_.InvocationInfo.PositionMessage)`r`n", [System.Text.Encoding]::UTF8)
        [System.IO.File]::AppendAllText($global:logFile, "$ts  !!! 堆栈: $($_.ScriptStackTrace)`r`n", [System.Text.Encoding]::UTF8)
    } catch {}
    continue
}

# AppDomain 未捕获异常
try {
    [System.AppDomain]::CurrentDomain.add_UnhandledException({
        param($s, $e)
        Log "!!! AppDomain 未捕获: $($e.ExceptionObject)"
    })
    Log "AppDomain 异常钩子已注册"
} catch { Log "注册 AppDomain 钩子失败: $_" }

# ============================================================
# 1. 加载程序集
# ============================================================
Log "开始 Add-Type..."
try {
    Add-Type -AssemblyName PresentationFramework
    Add-Type -AssemblyName PresentationCore
    Add-Type -AssemblyName WindowsBase
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    Log "Add-Type 完成"
} catch {
    Log "!!! Add-Type 失败: $_"
    throw
}

$global:dataFile  = Join-Path $scriptDir "tasks.json"
$global:attachDir = Join-Path $scriptDir "attachments"

if (-not (Test-Path $global:attachDir)) {
    New-Item -ItemType Directory -Path $global:attachDir | Out-Null
    Log "已创建 attachments 目录"
}

# ============================================================
# 2. 加载数据（任何异常都不能阻止启动）
# ============================================================
Log "开始加载数据..."
$global:TodoData = $null
try {
    if (Test-Path $global:dataFile) {
        $rawJson = Get-Content $global:dataFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $rawJson) { throw "JSON 为空" }
        if ($rawJson -is [array]) {
            $global:TodoData = [PSCustomObject]@{ x=1200; y=150; w=360; h=500; opacity=0.8; scale=1.0; showCompleted=$true; viewMode="grid"; edgeSide="right"; tasks=$rawJson }
        } else {
            $global:TodoData = $rawJson
        }
        $global:TodoData.tasks = @($global:TodoData.tasks)
        $global:lastKnownTaskCount = @($global:TodoData.tasks).Count
        Log "数据加载成功，任务数: $($global:TodoData.tasks.Count)"
    } else {
        $global:TodoData = [PSCustomObject]@{ x=1200; y=150; w=360; h=500; opacity=0.8; scale=1.0; showCompleted=$true; viewMode="grid"; edgeSide="right"; tasks=@() }
        Log "无数据文件，使用默认结构"
    }
} catch {
    Log "!!! 数据加载失败，使用默认结构: $_"
    $global:TodoData = [PSCustomObject]@{ x=1200; y=150; w=360; h=500; opacity=0.8; scale=1.0; showCompleted=$true; viewMode="grid"; edgeSide="right"; tasks=@() }
}

# 字段兜底
try {
    foreach ($kv in @{opacity=0.8; showCompleted=$true; scale=1.0; w=360; h=500; viewMode="grid"; edgeSide="right"; skin="dark"}.GetEnumerator()) {
        if ($null -eq (Get-Member -InputObject $global:TodoData -Name $kv.Key -MemberType Properties)) {
            $global:TodoData | Add-Member -MemberType NoteProperty -Name $kv.Key -Value $kv.Value
        }
    }
    if ($global:TodoData.viewMode -notin @("grid","list","edge")) { $global:TodoData.viewMode = "grid" }

    foreach ($t in $global:TodoData.tasks) {
        if (-not (Get-Member -InputObject $t -Name "paths" -MemberType Properties)) { $t | Add-Member -MemberType NoteProperty -Name "paths" -Value @() }
        if ((Get-Member -InputObject $t -Name "path" -MemberType Properties) -and $t.path) {
            if ($t.paths -notcontains $t.path) { $t.paths += $t.path }
            $t.path = $null
        }
        $t.paths = @($t.paths)
    }
    Log "字段兜底完成，viewMode=$($global:TodoData.viewMode)"
} catch {
    Log "!!! 字段兜底失败: $_"
}

$bc = New-Object System.Windows.Media.BrushConverter
function Get-Color([string]$hex) { return $bc.ConvertFromString($hex) }

function Set-SkinColor([string]$hex) {
    if ($global:TodoData -and $global:TodoData.skin -eq "pastel") {
        $map = @{
            "#0D0D0F"="#F0F0F5"; "#101014"="#F0F0F0"; "#16161A"="#FFFFFF"
            "#202026"="#E8E8E8"; "#25252A"="#E0E0E8"; "#2A2A30"="#D8D8E0"
            "#303036"="#C8C8D0"; "#49454F"="#8A8A8A"; "#60606B"="#5A5A5A"
            "#8B8B96"="#5A5A5A"; "#B0B0BA"="#606060"; "#C0C0C8"="#6E6E6E"
            "#EBEBEB"="#2A2A2A"; "#E2B75A"="#2C5C9E"; "#F0C86A"="#2C5C9E"
            "#FFD700"="#1A1A1A"; "#4A4A58"="#C0C0C0"
        }
        $key = $hex.ToUpper()
        if ($map.ContainsKey($key)) { return $bc.ConvertFromString($map[$key]) }
    }
    return $bc.ConvertFromString($hex)
}

function Save-Data {
    try {
        $currentCount = @($global:TodoData.tasks).Count
        if ($global:lastKnownTaskCount -gt 3 -and $currentCount -lt [Math]::Floor($global:lastKnownTaskCount / 2)) {
            Log "!!! 拒绝保存：任务数从 $($global:lastKnownTaskCount) 骤降到 $currentCount"
            return
        }
        # 写前先滚动备份（保留最近 10 份）
        if (Test-Path $global:dataFile) {
            $bkDir = Join-Path $scriptDir "_backups"
            if (-not (Test-Path $bkDir)) { New-Item -ItemType Directory -Path $bkDir -Force | Out-Null }

            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $bkFile = Join-Path $bkDir "tasks_$stamp.json"
            try { Copy-Item $global:dataFile $bkFile -Force } catch {}

            # 只保留最近 10 份
            $old = Get-ChildItem $bkDir -Filter "tasks_*.json" |
                   Sort-Object LastWriteTime -Descending |
                   Select-Object -Skip 10
            foreach ($f in $old) { try { Remove-Item $f.FullName -Force } catch {} }
        }

        $global:TodoData | ConvertTo-Json -Depth 5 | Out-File $global:dataFile -Encoding UTF8
        $global:lastKnownTaskCount = @($global:TodoData.tasks).Count
    } catch { Log "!!! Save-Data 失败: $_" }
}

# ============================================================
# 2.5 首次运行：在本程序文件夹里生成一个带图标的快捷方式（只建一次）
#     生成后可随意拖到桌面 / 任务栏 / 开始菜单，程序不会再重复生成
# ============================================================
function New-AppShortcutIfNeeded {
    try {
        if ($global:TodoData.shortcutMade) {
            Log "快捷方式已生成过，跳过"
            return
        }
        $vbsPath = Join-Path $scriptDir "TodoLauncher.vbs"
        if (-not (Test-Path -LiteralPath $vbsPath)) {
            Log "!!! 未找到 TodoLauncher.vbs，跳过生成快捷方式"
            return
        }
        $lnkPath = Join-Path $scriptDir "Todo.lnk"
        if (Test-Path -LiteralPath $lnkPath) {
            Log "快捷方式文件已存在，只补标记"
        } else {
            $wsh = New-Object -ComObject WScript.Shell
            $sc = $wsh.CreateShortcut($lnkPath)
            $sc.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
            $sc.Arguments = '"' + $vbsPath + '"'
            $sc.WorkingDirectory = $scriptDir
            $icoPath = Join-Path $scriptDir "icon.ico"
            if (Test-Path -LiteralPath $icoPath) { $sc.IconLocation = $icoPath + ",0" }
            $sc.Description = "Todo 桌面待办"
            $sc.WindowStyle = 1
            $sc.Save()
            Log "已生成快捷方式: $lnkPath"
        }
        $global:TodoData | Add-Member -MemberType NoteProperty -Name "shortcutMade" -Value $true -Force
        Save-Data
    } catch {
        Log "!!! 生成快捷方式失败: $_"
    }
}

New-AppShortcutIfNeeded

# ============================================================
# 3. 创建窗口
# ============================================================
Log "创建窗口..."
$window = New-Object System.Windows.Window
$window.Title = "TASKS"
$window.SizeToContent = [System.Windows.SizeToContent]::Manual
$window.WindowStyle = [System.Windows.WindowStyle]::None
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.Topmost = $true
$window.ShowInTaskbar = $false
$window.AllowDrop = $true
$window.MinWidth = 250
$window.MinHeight = 250
$window.FontFamily = New-Object System.Windows.Media.FontFamily("Microsoft YaHei, Meiryo")

$iconPath = Join-Path $scriptDir "icon.ico"
if (Test-Path $iconPath) {
    $sysIcon = New-Object System.Drawing.Icon($iconPath)
    $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([System.Uri]::new($iconPath))
} else {
    $sysIcon = [System.Drawing.Icon]::ExtractAssociatedIcon("$pshome\powershell.exe")
}

try { $window.Left = [double]$global:TodoData.x } catch { $window.Left = 200 }
try { $window.Top  = [double]$global:TodoData.y } catch { $window.Top = 150 }
try { $window.Width = [double]$global:TodoData.w } catch { $window.Width = 360 }
try { $window.Height = [double]$global:TodoData.h } catch { $window.Height = 500 }

# ============================================================
# 4. Dispatcher 异常捕获（关键！防闪退核心）
# ============================================================
try {
$window.Dispatcher.add_UnhandledException({
    param($s, $e)
    try {
        $ts = Get-Date -Format "HH:mm:ss.fff"
        $msg = "$ts  !!! DispatcherUnhandled: $($e.Exception.GetType().FullName)`r`n" +
               "$ts  !!! 消息: $($e.Exception.Message)`r`n" +
               "$ts  !!! 堆栈: $($e.Exception.StackTrace)`r`n"
        try { [System.IO.File]::AppendAllText($global:logFile, $msg, [System.Text.Encoding]::UTF8) } catch {}
    } catch {}
    $e.Handled = $true
})
    Log "Dispatcher 异常钩子已注册"
} catch {
    Log "!!! 注册 Dispatcher 钩子失败: $_"
}

# ============================================================
# 5. 全局状态
# ============================================================
$global:edgeState    = "normal"
$global:mainContent  = $null
$global:switching    = $false
$global:lastExpandAt = [DateTime]::MinValue

function Toggle-Topmost {
    try {
        $window.Topmost = -not $window.Topmost
        if ($window.Topmost) { $BtnPin.Foreground = Set-SkinColor "#E2B75A"; $menuPinItem.Checked = $true }
        else { $BtnPin.Foreground = Set-SkinColor "#B0B0BA"; $menuPinItem.Checked = $false }
        Log "Topmost -> $($window.Topmost)"
    } catch { Log "!!! Toggle-Topmost: $_" }
}

# ============================================================
# 6. 托盘
# ============================================================
Log "创建托盘..."
$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = $sysIcon
$tray.Text = "Todo"
$tray.Visible = $true

$trayMenu = New-Object System.Windows.Forms.ContextMenu

$menuShowItem = New-Object System.Windows.Forms.MenuItem
$menuShowItem.Text = "显示 / 隐藏面板"
$menuShowItem.Add_Click({
    try {
        if ($window.Visibility -eq [System.Windows.Visibility]::Visible) { $window.Hide(); Log "面板已隐藏" }
        else { $window.Show(); $window.Activate(); Log "面板已显示" }
    } catch { Log "!!! 托盘 显示/隐藏: $_" }
})

$menuPinItem = New-Object System.Windows.Forms.MenuItem
$menuPinItem.Text = "总在最前 (Topmost)"
$menuPinItem.Checked = $window.Topmost
$menuPinItem.Add_Click({ Toggle-Topmost })

$menuEdgeModeItem = New-Object System.Windows.Forms.MenuItem
$menuEdgeModeItem.Text = "🧲 边缘吸附模式 (Edge Dock)"
$menuEdgeModeItem.Checked = ($global:TodoData.viewMode -eq "edge")
$menuEdgeModeItem.Add_Click({
    try {
        Log "托盘: 点击 边缘吸附模式. 当前 viewMode=$($global:TodoData.viewMode)"
        if ($global:TodoData.viewMode -eq "edge") {
            $global:TodoData.viewMode = "grid"
            $menuEdgeModeItem.Checked = $false
            $BtnView.Content = "≣"
            Exit-EdgeMode
            Render-List
            Log "托盘: 已退出 Edge 模式"
        } else {
            $global:TodoData.viewMode = "edge"
            $menuEdgeModeItem.Checked = $true
            $BtnView.Content = "◧"
            Enter-EdgeMode
            Log "托盘: 已进入 Edge 模式"
        }
        Save-Data
    } catch {
        Log "!!! 托盘 切换 Edge 失败: $_"
        Log "!!! 堆栈: $($_.ScriptStackTrace)"
        # 兜底：回退普通模式
        try {
            $global:TodoData.viewMode = "grid"
            $menuEdgeModeItem.Checked = $false
            $BtnView.Content = "≣"
            Exit-EdgeMode
            Render-List
        } catch {}
    }
})

# 皮肤切换菜单项
$menuSkinItem = New-Object System.Windows.Forms.MenuItem
$menuSkinItem.Text = "🎨 切换皮肤 (Dark / Pastel)"
$menuSkinItem.Add_Click({
    try {
        if ($global:TodoData.skin -eq "pastel") { $global:TodoData.skin = "dark" } else { $global:TodoData.skin = "pastel" }
        Save-Data

        # 刷新所有顶层可见元素
        try {
            $mainBorder.Background = Set-SkinColor "#0D0D0F"
            $mainBorder.BorderBrush = Set-SkinColor "#25252A"
            $inputBorder.Background = Set-SkinColor "#16161A"
            $inputBorder.BorderBrush = Set-SkinColor "#25252A"
            $InputTask.Foreground = Set-SkinColor "#B0B0BA"
            $InputTask.CaretBrush = Set-SkinColor "#EBEBEB"
            $TitleText.Foreground = Set-SkinColor "#E2B75A"
            $BtnClose.Foreground = Set-SkinColor "#B0B0BA"
            $BtnMenu.Foreground = Set-SkinColor "#B0B0BA"
            $BtnView.Foreground = Set-SkinColor "#B0B0BA"
            $BtnPin.Foreground = Set-SkinColor "#B0B0BA"
        } catch { Log "!!! 皮肤刷新顶层失败: $_" }

        # 重建任务列表（卡片背景跟随皮肤）
        Render-List

        # 若在 Edge 模式，重新铺 Dock（用 -Force 绕过锁）
        if ($global:TodoData.viewMode -eq "edge") {
            $global:edgeExpandedLocked = $false
            Enter-EdgeMode
        }
        Log "皮肤已切换: $($global:TodoData.skin)"
    } catch { Log "!!! 切换皮肤失败: $_" }
})

$menuResetPosItem = New-Object System.Windows.Forms.MenuItem
$menuResetPosItem.Text = "初始化位置 (Reset Position)"
$menuResetPosItem.Add_Click({
    try {
        if ($global:TodoData.viewMode -eq "edge") {
            $global:TodoData.viewMode = "grid"
            $menuEdgeModeItem.Checked = $false
            $BtnView.Content = "≣"
            Exit-EdgeMode
        }
        $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $newLeft = ($wa.Width - $window.Width) / 2 + $wa.X
        $newTop  = ($wa.Height - $window.Height) / 2 + $wa.Y
        $window.Left = $newLeft; $window.Top = $newTop
        $global:TodoData.x = $newLeft; $global:TodoData.y = $newTop
        Save-Data
        $window.Activate()
        Log "位置已重置"
    } catch { Log "!!! 重置位置失败: $_" }
})

$menuManageTrayItem = New-Object System.Windows.Forms.MenuItem
$menuManageTrayItem.Text = "管理目录 (Open Folder)"
$menuManageTrayItem.Add_Click({ try { [System.Diagnostics.Process]::Start("explorer.exe", $scriptDir) | Out-Null } catch {} })

$menuExitItem = New-Object System.Windows.Forms.MenuItem
$menuExitItem.Text = "彻底退出 (Exit)"
$menuExitItem.Add_Click({
    try {
        Log "用户选择退出"
        $tray.Visible = $false; $tray.Dispose()
        $window.Close()
    } catch { Log "!!! 退出失败: $_" }
})

[void]$trayMenu.MenuItems.Add($menuShowItem)
[void]$trayMenu.MenuItems.Add($menuPinItem)
[void]$trayMenu.MenuItems.Add($menuEdgeModeItem)
[void]$trayMenu.MenuItems.Add($menuSkinItem)
[void]$trayMenu.MenuItems.Add($menuResetPosItem)
[void]$trayMenu.MenuItems.Add($menuManageTrayItem)
[void]$trayMenu.MenuItems.Add("-")
[void]$trayMenu.MenuItems.Add($menuExitItem)
$tray.ContextMenu = $trayMenu
$tray.Add_DoubleClick({ Toggle-Topmost })
Log "托盘创建完成"

# ============================================================
# 7. UI 骨架
# ============================================================
Log "构建 UI..."
$outerGrid = New-Object System.Windows.Controls.Grid
$outerGrid.Background = [System.Windows.Media.Brushes]::Transparent

$mainBorder = New-Object System.Windows.Controls.Border
$mainBorder.Margin = "25"
$mainBorder.Background = Set-SkinColor "#0D0D0F"
$mainBorder.BorderBrush = Set-SkinColor "#25252A"
$mainBorder.BorderThickness = 1
$mainBorder.CornerRadius = 10
$mainBorder.Padding = "14"
$mainBorder.Opacity = $global:TodoData.opacity

$scaleTransform = New-Object System.Windows.Media.ScaleTransform
$scaleTransform.ScaleX = $global:TodoData.scale
$scaleTransform.ScaleY = $global:TodoData.scale
$mainBorder.LayoutTransform = $scaleTransform

$shadow = New-Object System.Windows.Media.Effects.DropShadowEffect
$shadow.Color = (Set-SkinColor "#000000").Color
$shadow.BlurRadius = 30; $shadow.ShadowDepth = 5; $shadow.Opacity = 0.6
$mainBorder.Effect = $shadow

$mainBorder.Add_MouseEnter({ param($s, $e) $mainBorder.Opacity = 1.0 })
$mainBorder.Add_MouseLeave({ param($s, $e) $mainBorder.Opacity = $global:TodoData.opacity })

$grid = New-Object System.Windows.Controls.Grid
[void]$grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
[void]$grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))
[void]$grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=New-Object System.Windows.GridLength(1, [System.Windows.GridUnitType]::Star)}))

$DragBar = New-Object System.Windows.Controls.DockPanel
$DragBar.Margin = "0,0,0,14"
$DragBar.Background = [System.Windows.Media.Brushes]::Transparent
[System.Windows.Controls.Grid]::SetRow($DragBar, 0)

$BtnClose = New-Object System.Windows.Controls.Button
$BtnClose.Content = "✕"; $BtnClose.Background = [System.Windows.Media.Brushes]::Transparent
$BtnClose.BorderThickness = 0; $BtnClose.Foreground = Set-SkinColor "#B0B0BA"
$BtnClose.Cursor = [System.Windows.Input.Cursors]::Hand; $BtnClose.Width = 20
$BtnClose.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
$BtnClose.Add_MouseEnter({ param($s, $e) $s.Foreground = Set-SkinColor "#EBEBEB" })
$BtnClose.Add_MouseLeave({ param($s, $e) $s.Foreground = Set-SkinColor "#B0B0BA" })
[System.Windows.Controls.DockPanel]::SetDock($BtnClose, [System.Windows.Controls.Dock]::Right)

$BtnMenu = New-Object System.Windows.Controls.Button
$BtnMenu.Content = "≡"; $BtnMenu.Background = [System.Windows.Media.Brushes]::Transparent
$BtnMenu.BorderThickness = 0; $BtnMenu.Foreground = Set-SkinColor "#B0B0BA"
$BtnMenu.Cursor = [System.Windows.Input.Cursors]::Hand; $BtnMenu.Width = 22
$BtnMenu.Margin = "0,0,2,0"; $BtnMenu.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
$BtnMenu.Add_MouseEnter({ param($s, $e) $s.Foreground = Set-SkinColor "#EBEBEB" })
$BtnMenu.Add_MouseLeave({ param($s, $e) $s.Foreground = Set-SkinColor "#B0B0BA" })
[System.Windows.Controls.DockPanel]::SetDock($BtnMenu, [System.Windows.Controls.Dock]::Right)

$BtnView = New-Object System.Windows.Controls.Button
switch ($global:TodoData.viewMode) {
    "grid" { $BtnView.Content = "≣" }
    "list" { $BtnView.Content = "⊞" }
    "edge" { $BtnView.Content = "◧" }
    default { $BtnView.Content = "≣" }
}
$BtnView.Background = [System.Windows.Media.Brushes]::Transparent
$BtnView.BorderThickness = 0; $BtnView.Foreground = Set-SkinColor "#B0B0BA"
$BtnView.Cursor = [System.Windows.Input.Cursors]::Hand; $BtnView.Width = 22
$BtnView.Margin = "0,0,2,0"; $BtnView.ToolTip = "白板 / 列表 / 边缘"
$BtnView.Add_MouseEnter({ param($s, $e) $s.Foreground = Set-SkinColor "#EBEBEB" })
$BtnView.Add_MouseLeave({ param($s, $e) $s.Foreground = Set-SkinColor "#B0B0BA" })
[System.Windows.Controls.DockPanel]::SetDock($BtnView, [System.Windows.Controls.Dock]::Right)

# 菜单 Popup
$popup = New-Object System.Windows.Controls.Primitives.Popup
$popup.StaysOpen = $false; $popup.PlacementTarget = $BtnMenu
$popup.Placement = [System.Windows.Controls.Primitives.PlacementMode]::Bottom
$popup.VerticalOffset = 8; $popup.HorizontalOffset = -10

$popBorder = New-Object System.Windows.Controls.Border
$popBorder.Background = Set-SkinColor "#16161A"; $popBorder.BorderBrush = Set-SkinColor "#303036"
$popBorder.BorderThickness = 1; $popBorder.CornerRadius = 6; $popBorder.Padding = "4"
$popStack = New-Object System.Windows.Controls.StackPanel
$popBorder.Child = $popStack; $popup.Child = $popBorder

function New-MenuRow {
    param([string]$text)
    $row = New-Object System.Windows.Controls.Border
    $row.Background = [System.Windows.Media.Brushes]::Transparent
    $row.CornerRadius = 4; $row.Padding = "12,8"
    $row.Cursor = [System.Windows.Input.Cursors]::Hand
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $text; $tb.Foreground = Set-SkinColor "#EBEBEB"; $tb.FontSize = 12
    $row.Child = $tb
    $row.Add_MouseEnter({ param($s, $e) $s.Background = Set-SkinColor "#303036" })
    $row.Add_MouseLeave({ param($s, $e) $s.Background = [System.Windows.Media.Brushes]::Transparent })
    return @{ row = $row; text = $tb }
}

$menuZoom = New-MenuRow "🔍 密度: $([math]::Round($global:TodoData.scale * 100))%"
$menuZoom.row.Add_MouseLeftButtonDown({
    param($s, $e); $e.Handled = $true
    try {
        $newScale = [math]::Round($global:TodoData.scale + 0.1, 1); if ($newScale -gt 1.5) { $newScale = 0.8 }
        $global:TodoData.scale = $newScale
        $menuZoom.text.Text = "🔍 密度: $([math]::Round($newScale * 100))%"
        $InputTask.FontSize = 12 * $newScale
        $inputBorder.Padding = "$(8 * $newScale),$(6 * $newScale)"
        Save-Data; Render-List
    } catch { Log "!!! 密度调整: $_" }
})
[void]$popStack.Children.Add($menuZoom.row)

$menuOp = New-MenuRow "🌗 透明度: $([math]::Round($global:TodoData.opacity * 100))%"
$menuOp.row.Add_MouseLeftButtonDown({
    param($s, $e); $e.Handled = $true
    try {
        $newOp = [math]::Round($global:TodoData.opacity + 0.1, 1); if ($newOp -gt 1.0) { $newOp = 0.4 }
        $global:TodoData.opacity = $newOp
        $menuOp.text.Text = "🌗 透明度: $([math]::Round($newOp * 100))%"
        $mainBorder.Opacity = $newOp; Save-Data
    } catch { Log "!!! 透明度调整: $_" }
})
[void]$popStack.Children.Add($menuOp.row)

$menuShow = New-MenuRow $(if($global:TodoData.showCompleted){"👁 已完成: 显示"}else{"👁 已完成: 隐藏"})
$menuShow.row.Add_MouseLeftButtonDown({
    param($s, $e); $e.Handled = $true
    try {
        $global:TodoData.showCompleted = -not $global:TodoData.showCompleted
        $menuShow.text.Text = if($global:TodoData.showCompleted){"👁 已完成: 显示"}else{"👁 已完成: 隐藏"}
        Save-Data; Render-List
    } catch { Log "!!! 切换显示完成: $_" }
})
[void]$popStack.Children.Add($menuShow.row)

$sep = New-Object System.Windows.Controls.Border
$sep.Height = 1; $sep.Background = Set-SkinColor "#303036"; $sep.Margin = "4,4,4,4"
[void]$popStack.Children.Add($sep)

$menuFolder = New-MenuRow "📂 管理目录"
$menuFolder.row.Add_MouseLeftButtonDown({
    param($s, $e)
    try {
        $popup.IsOpen = $false
        [System.Diagnostics.Process]::Start("explorer.exe", $scriptDir) | Out-Null
    } catch { Log "!!! 打开目录: $_" }
})
[void]$popStack.Children.Add($menuFolder.row)

# ★ 内嵌菜单也加 Edge 模式
$menuEdge = New-MenuRow "🧲 边缘吸附模式"
$menuEdge.row.Add_MouseLeftButtonDown({
    param($s, $e); $e.Handled = $true
    try {
        $popup.IsOpen = $false
        if ($global:TodoData.viewMode -eq "edge") {
            $global:TodoData.viewMode = "grid"
            $menuEdgeModeItem.Checked = $false
            $BtnView.Content = "≣"
            Exit-EdgeMode; Render-List
        } else {
            $global:TodoData.viewMode = "edge"
            $menuEdgeModeItem.Checked = $true
            $BtnView.Content = "◧"
            Enter-EdgeMode
        }
        Save-Data
    } catch { Log "!!! 内嵌菜单 Edge 切换: $_" }
})
[void]$popStack.Children.Add($menuEdge.row)

$BtnMenu.Add_Click({ param($sender, $e) $popup.IsOpen = $true })

$BtnPin = New-Object System.Windows.Controls.Button
$BtnPin.Content = "📌"; $BtnPin.Background = [System.Windows.Media.Brushes]::Transparent
$BtnPin.BorderThickness = 0
$BtnPin.Foreground = if ($window.Topmost) { Set-SkinColor "#E2B75A" } else { Set-SkinColor "#B0B0BA" }
$BtnPin.Cursor = [System.Windows.Input.Cursors]::Hand; $BtnPin.Width = 24
$BtnPin.Margin = "0,0,2,0"; $BtnPin.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
$BtnPin.Add_MouseEnter({ param($s, $e) if(-not $window.Topmost){$s.Foreground = Set-SkinColor "#EBEBEB"} })
$BtnPin.Add_MouseLeave({ param($s, $e) if(-not $window.Topmost){$s.Foreground = Set-SkinColor "#B0B0BA"} })
[System.Windows.Controls.DockPanel]::SetDock($BtnPin, [System.Windows.Controls.Dock]::Right)

$TitleText = New-Object System.Windows.Controls.TextBlock
$TitleText.Text = "Todo"; $TitleText.FontSize = 11
$TitleText.FontWeight = [System.Windows.FontWeights]::Bold
$TitleText.Foreground = Set-SkinColor "#E2B75A"
$TitleText.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
[System.Windows.Controls.DockPanel]::SetDock($TitleText, [System.Windows.Controls.Dock]::Left)

$DragSpacer = New-Object System.Windows.Controls.Border
$DragSpacer.Background = [System.Windows.Media.Brushes]::Transparent
[System.Windows.Controls.DockPanel]::SetDock($DragSpacer, [System.Windows.Controls.Dock]::Left)

[void]$DragBar.Children.Add($BtnClose)
[void]$DragBar.Children.Add($BtnMenu)
[void]$DragBar.Children.Add($BtnView)
[void]$DragBar.Children.Add($BtnPin)
[void]$DragBar.Children.Add($TitleText)
[void]$DragBar.Children.Add($DragSpacer)

$inputBorder = New-Object System.Windows.Controls.Border
$inputBorder.Background = Set-SkinColor "#16161A"
$inputBorder.CornerRadius = 6; $inputBorder.BorderBrush = Set-SkinColor "#25252A"
$inputBorder.BorderThickness = 1; $inputBorder.Margin = "0,0,0,12"
$inputBorder.Padding = "$(8 * $global:TodoData.scale),$(6 * $global:TodoData.scale)"
[System.Windows.Controls.Grid]::SetRow($inputBorder, 1)

$InputTask = New-Object System.Windows.Controls.TextBox
$InputTask.Background = [System.Windows.Media.Brushes]::Transparent
$InputTask.BorderThickness = 0; $InputTask.Foreground = Set-SkinColor "#B0B0BA"
$InputTask.CaretBrush = Set-SkinColor "#EBEBEB"
$InputTask.FontSize = 12 * $global:TodoData.scale
$placeholderText = " 键入任务或拖入文件(Shift+Enter换行)..."
$InputTask.Text = $placeholderText
$InputTask.AcceptsReturn = $true; $InputTask.MaxLines = 5
$InputTask.VerticalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Auto
$inputBorder.Child = $InputTask

$scrollViewer = New-Object System.Windows.Controls.ScrollViewer
$scrollViewer.VerticalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Hidden
$scrollViewer.HorizontalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Disabled
[System.Windows.Controls.Grid]::SetRow($scrollViewer, 2)

$ListContainer = New-Object System.Windows.Controls.StackPanel
$scrollViewer.Content = $ListContainer

[void]$grid.Children.Add($DragBar)
[void]$grid.Children.Add($inputBorder)
[void]$grid.Children.Add($scrollViewer)
$mainBorder.Child = $grid
[void]$outerGrid.Children.Add($mainBorder)

# Resize handles
$global:isResizing = $false; $global:resizeMode = ""; $global:startMousePos = $null; $global:startWinRect = $null

function Create-ResizeHandle([string]$name, [string]$cursor, [string]$hAlign, [string]$vAlign) {
    $handle = New-Object System.Windows.Controls.Border
    $handle.Name = $name; $handle.Width = 24; $handle.Height = 24; $handle.Margin = "16"
    $handle.Background = [System.Windows.Media.Brushes]::Transparent
    $handle.Cursor = [System.Windows.Input.Cursors]::$cursor
    $handle.HorizontalAlignment = [System.Windows.HorizontalAlignment]::$hAlign
    $handle.VerticalAlignment = [System.Windows.VerticalAlignment]::$vAlign
    $handle.Add_MouseLeftButtonDown({
        param($sender, $e); $e.Handled = $true
        if ($global:edgeState -ne "normal") { return }
        try {
            $global:isResizing = $true; $global:resizeMode = $sender.Name
            $global:startMousePos = [System.Windows.Forms.Cursor]::Position
            $global:startWinRect = @{ L=$window.Left; T=$window.Top; W=$window.Width; H=$window.Height }
            [void]$sender.CaptureMouse()
        } catch { Log "!!! Resize 开始: $_" }
    })
    $handle.Add_MouseMove({
        param($sender, $e)
        if ($global:isResizing -and $global:resizeMode -eq $sender.Name) {
            try {
                $c = [System.Windows.Forms.Cursor]::Position
                $dx = $c.X - $global:startMousePos.X; $dy = $c.Y - $global:startMousePos.Y
                switch ($global:resizeMode) {
                    "BR" { $nw = $global:startWinRect.W + $dx; $nh = $global:startWinRect.H + $dy; if ($nw -ge $window.MinWidth) { $window.Width = $nw }; if ($nh -ge $window.MinHeight) { $window.Height = $nh } }
                    "BL" { $nw = $global:startWinRect.W - $dx; $nh = $global:startWinRect.H + $dy; if ($nw -ge $window.MinWidth) { $window.Left = $global:startWinRect.L + $dx; $window.Width = $nw }; if ($nh -ge $window.MinHeight) { $window.Height = $nh } }
                    "TR" { $nw = $global:startWinRect.W + $dx; $nh = $global:startWinRect.H - $dy; if ($nw -ge $window.MinWidth) { $window.Width = $nw }; if ($nh -ge $window.MinHeight) { $window.Top = $global:startWinRect.T + $dy; $window.Height = $nh } }
                    "TL" { $nw = $global:startWinRect.W - $dx; $nh = $global:startWinRect.H - $dy; if ($nw -ge $window.MinWidth) { $window.Left = $global:startWinRect.L + $dx; $window.Width = $nw }; if ($nh -ge $window.MinHeight) { $window.Top = $global:startWinRect.T + $dy; $window.Height = $nh } }
                }
            } catch { Log "!!! Resize 移动: $_" }
        }
    })
    $handle.Add_MouseLeftButtonUp({
        param($sender, $e)
        if ($global:isResizing) {
            try {
                $global:isResizing = $false; [void]$sender.ReleaseMouseCapture()
                $global:TodoData.w = $window.Width; $global:TodoData.h = $window.Height
                $global:TodoData.x = $window.Left; $global:TodoData.y = $window.Top
                Save-Data
            } catch { Log "!!! Resize 结束: $_" }
        }
    })
    return $handle
}

[void]$outerGrid.Children.Add((Create-ResizeHandle "TL" "SizeNWSE" "Left" "Top"))
[void]$outerGrid.Children.Add((Create-ResizeHandle "TR" "SizeNESW" "Right" "Top"))
[void]$outerGrid.Children.Add((Create-ResizeHandle "BL" "SizeNESW" "Left" "Bottom"))
[void]$outerGrid.Children.Add((Create-ResizeHandle "BR" "SizeNWSE" "Right" "Bottom"))

$window.Content = $outerGrid
$global:mainContent = $outerGrid
Log "UI 骨架创建完成"

# ============================================================
# 8. Render-List
# ============================================================
function Render-List {
    try {
        Log "Render-List 开始. viewMode=$($global:TodoData.viewMode), 任务数=$($global:TodoData.tasks.Count)"
        $ListContainer.Children.Clear()
        $s = $global:TodoData.scale
        $viewMode = if ($global:TodoData.viewMode -eq "edge") { "list" } else { $global:TodoData.viewMode }

        $activeTasks = @($global:TodoData.tasks | Where-Object { $_.done -eq $false }) | Sort-Object category
        $completedTasks = @($global:TodoData.tasks | Where-Object { $_.done -eq $true }) | Sort-Object category

        function Attach-CustomMenu($uiElement, $task) {
            try {
                $pop = New-Object System.Windows.Controls.Primitives.Popup
                $pop.StaysOpen = $false; $pop.PlacementTarget = $uiElement
                $pop.Placement = [System.Windows.Controls.Primitives.PlacementMode]::MousePoint
                $pBorder = New-Object System.Windows.Controls.Border
                $pBorder.Background = Set-SkinColor "#16161A"; $pBorder.BorderBrush = Set-SkinColor "#303036"
                $pBorder.BorderThickness = 1; $pBorder.CornerRadius = 4; $pBorder.Padding = "4"
                $pStack = New-Object System.Windows.Controls.StackPanel

                $btnDone = New-Object System.Windows.Controls.Border
                $btnDone.Background = [System.Windows.Media.Brushes]::Transparent
                $btnDone.CornerRadius = 2; $btnDone.Padding = "12,6"
                $btnDone.Cursor = [System.Windows.Input.Cursors]::Hand; $btnDone.Tag = $task
                $tbDone = New-Object System.Windows.Controls.TextBlock
                $tbDone.Text = if($task.done){"⚪ 取消完成"}else{"🟣 标记完成"}
                $tbDone.Foreground = Set-SkinColor "#B0B0BA"
                $btnDone.Child = $tbDone
                $btnDone.Add_MouseEnter({ param($s, $e) $s.Background = Set-SkinColor "#303036" })
                $btnDone.Add_MouseLeave({ param($s, $e) $s.Background = [System.Windows.Media.Brushes]::Transparent })
                $btnDone.Add_MouseLeftButtonDown({
                    param($s, $e); $e.Handled = $true; $pop.IsOpen = $false
                    try { $tsk = $s.Tag; $tsk.done = -not $tsk.done; Save-Data; Render-List }
                    catch { Log "!!! 菜单 完成切换: $_" }
                })
                [void]$pStack.Children.Add($btnDone)

                $btnTop = New-Object System.Windows.Controls.Border
                $btnTop.Background = [System.Windows.Media.Brushes]::Transparent
                $btnTop.CornerRadius = 2; $btnTop.Padding = "12,6"
                $btnTop.Cursor = [System.Windows.Input.Cursors]::Hand; $btnTop.Tag = $task
                $tbTop = New-Object System.Windows.Controls.TextBlock
                $tbTop.Text = "⬆️ 置顶任务"; $tbTop.Foreground = Set-SkinColor "#B0B0BA"
                $btnTop.Child = $tbTop
                $btnTop.Add_MouseEnter({ param($s, $e) $s.Background = Set-SkinColor "#303036" })
                $btnTop.Add_MouseLeave({ param($s, $e) $s.Background = [System.Windows.Media.Brushes]::Transparent })
                $btnTop.Add_MouseLeftButtonDown({
                    param($s, $e); $e.Handled = $true; $pop.IsOpen = $false
                    try {
                        $tsk = $s.Tag
                        $temp = @($global:TodoData.tasks | Where-Object { $_ -ne $tsk })
                        $global:TodoData.tasks = @($tsk) + $temp
                        Save-Data; Render-List
                    } catch { Log "!!! 菜单 置顶: $_" }
                })
                [void]$pStack.Children.Add($btnTop)

                $pBorder.Child = $pStack; $pop.Child = $pBorder
                $uiElement.Add_PreviewMouseRightButtonUp({ param($sender, $e) $e.Handled = $true; $pop.IsOpen = $true })
            } catch { Log "!!! Attach-CustomMenu: $_" }
        }

        $activeGroups = $activeTasks | Group-Object category | Sort-Object Name
        $renderQueue = @()
        foreach ($g in $activeGroups) {
        $headerText = if ([string]::IsNullOrWhiteSpace($g.Name) -or $g.Name -eq "无") { "任务" } else { $g.Name }
        $renderQueue += @{ type="header"; text=$headerText; color=(Get-CategoryColor $g.Name) }
            if ($viewMode -eq "grid") { $renderQueue += @{ type="gridWrap"; items=$g.Group } }
            else { foreach ($t in $g.Group) { $renderQueue += @{ type="task"; data=$t } } }
        }
        if ($global:TodoData.showCompleted -and $completedTasks.Count -gt 0) {
        $renderQueue += @{ type="header"; text="已完成"; color="#49454F" }
            if ($viewMode -eq "grid") { $renderQueue += @{ type="gridWrap"; items=$completedTasks } }
            else { foreach ($t in $completedTasks) { $renderQueue += @{ type="task"; data=$t } } }
        }

        foreach ($item in $renderQueue) {
           if ($item.type -eq "header") {
    $hRow = New-Object System.Windows.Controls.StackPanel
    $hRow.Orientation = [System.Windows.Controls.Orientation]::Horizontal
    $hRow.Margin = "2,$(10 * $s),0,$(6 * $s)"

    $dot = New-Object System.Windows.Controls.Border
    $dot.Width = 8 * $s; $dot.Height = 8 * $s
    $dot.CornerRadius = 4 * $s
    $dot.Background = Get-Color $item.color
    $dot.Margin = "0,0,6,0"
    $dot.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    [void]$hRow.Children.Add($dot)

    $catLabel = New-Object System.Windows.Controls.TextBlock
    $catLabel.Text = $item.text
    $catLabel.Foreground = Set-SkinColor "#C0C0C8"
    $catLabel.FontSize = 10 * $s
    $catLabel.FontWeight = [System.Windows.FontWeights]::Bold
    $catLabel.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
    [void]$hRow.Children.Add($catLabel)

    [void]$ListContainer.Children.Add($hRow)
}
            elseif ($item.type -eq "gridWrap") {
                $wrap = New-Object System.Windows.Controls.WrapPanel
                $wrap.Margin = "0,0,0,$(6 * $s)"
                foreach ($t in $item.items) {
                    $card = New-Object System.Windows.Controls.Border
                    $card.Width = 150 * $s; $card.MinHeight = 80 * $s
                    $card.Margin = "0,0,$(10 * $s),$(10 * $s)"; $card.CornerRadius = 6 * $s
                    $card.BorderThickness = 1; $card.Background = Set-SkinColor "#16161A"
                    $card.Padding = "$(10 * $s),$(8 * $s)"
                    $card.BorderBrush = if ($t.done) { Set-SkinColor "#25252A" } else { Set-SkinColor "#2A2A30" }
                    $card.Opacity = if ($t.done) { 0.5 } else { 1.0 }
                    $card.Tag = $t
                    $card.Add_MouseEnter({ param($s, $e) $tsk = $s.Tag; if(-not $tsk.done){ $s.BorderBrush = Set-SkinColor "#E2B75A" } })
                    $card.Add_MouseLeave({ param($s, $e) $tsk = $s.Tag; if(-not $tsk.done){ $s.BorderBrush = Set-SkinColor "#2A2A30" } })
                    $card.AllowDrop = $true
                    $card.Add_DragEnter({ param($s, $e) $e.Handled = $true; if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) { $e.Effects = [System.Windows.DragDropEffects]::Copy } })
                    $card.Add_Drop({
                        param($sender, $e); $e.Handled = $true
                        try {
                            if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
                                $files = $e.Data.GetData([System.Windows.DataFormats]::FileDrop)
                                $tsk = $sender.Tag; $tempPaths = @($tsk.paths)
                                foreach ($file in $files) {
                                    $fileName = [System.IO.Path]::GetFileName($file)
                                    $destPath = Join-Path $global:attachDir $fileName
                                    try { Copy-Item -Path $file -Destination $destPath -Force } catch {}
                                    if ($tempPaths -notcontains $destPath) { $tempPaths += $destPath }
                                }
                                $tsk.paths = $tempPaths; Save-Data; Render-List
                            }
                        } catch { Log "!!! card Drop: $_" }
                    })

                    $cardGrid = New-Object System.Windows.Controls.Grid
                    [void]$cardGrid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=New-Object System.Windows.GridLength(1, [System.Windows.GridUnitType]::Star)}))
                    [void]$cardGrid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height=[System.Windows.GridLength]::Auto}))

                    $btnDone = New-Object System.Windows.Controls.Button
                    $btnDone.Content = if($t.done){"●"}else{"〇"}
                    $btnDone.Background = [System.Windows.Media.Brushes]::Transparent
                    $btnDone.BorderThickness = 0
                    $btnDone.Foreground = if($t.done){Set-SkinColor "#49454F"}else{Set-SkinColor "#60606B"}
                    $btnDone.Cursor = [System.Windows.Input.Cursors]::Hand; $btnDone.FontSize = 10 * $s
                    $btnDone.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
                    $btnDone.VerticalAlignment = [System.Windows.VerticalAlignment]::Top
                    $btnDone.Margin = "0,-4,-4,0"; $btnDone.Tag = $t
                    $btnDone.Add_MouseEnter({ param($s, $e) $tsk = $s.Tag; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#E2B75A" } })
                    $btnDone.Add_MouseLeave({ param($s, $e) $tsk = $s.Tag; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#60606B" } })
                    $btnDone.Add_Click({
                        param($s, $e)
                        try { $tsk = $s.Tag; $tsk.done = -not $tsk.done; Save-Data; Render-List }
                        catch { Log "!!! card 完成按钮: $_" }
                    })
                    [System.Windows.Controls.Grid]::SetRow($btnDone, 0)
                    [void]$cardGrid.Children.Add($btnDone)

                    $textGrid = New-Object System.Windows.Controls.Grid
                    $textGrid.Margin = "0,0,14,$(8 * $s)"

                    $rawText = $t.text; $idx = $rawText.IndexOf("`n")
                    if ($idx -ge 0) { $titleText = $rawText.Substring(0, $idx).Trim("`r"); $bodyText = $rawText.Substring($idx + 1) }
                    else { $titleText = $rawText; $bodyText = "" }

                    $displayBlock = New-Object System.Windows.Controls.TextBlock
                    $displayBlock.TextWrapping = [System.Windows.TextWrapping]::Wrap
                    $displayBlock.FontSize = 12 * $s
                    $displayBlock.Cursor = [System.Windows.Input.Cursors]::IBeam

                    $runTitle = New-Object System.Windows.Documents.Run
                    $runTitle.Text = $titleText
                    $runTitle.Foreground = if ($t.done) { Set-SkinColor "#60606B" } else { Set-SkinColor "#E2B75A" }
                    [void]$displayBlock.Inlines.Add($runTitle)
                    if ($bodyText) {
                        $runLB = New-Object System.Windows.Documents.Run; $runLB.Text = "`n"
                        [void]$displayBlock.Inlines.Add($runLB)
                        $runBody = New-Object System.Windows.Documents.Run; $runBody.Text = $bodyText
                        $runBody.Foreground = if ($t.done) { Set-SkinColor "#60606B" } else { Set-SkinColor "#EBEBEB" }
                        [void]$displayBlock.Inlines.Add($runBody)
                    }

                    $editBox = New-Object System.Windows.Controls.TextBox
                    $editBox.Text = $t.text; $editBox.Background = [System.Windows.Media.Brushes]::Transparent
                    $editBox.BorderThickness = 0; $editBox.Foreground = Set-SkinColor "#EBEBEB"
                    $editBox.CaretBrush = Set-SkinColor "#EBEBEB"; $editBox.FontSize = 12 * $s
                    $editBox.TextWrapping = [System.Windows.TextWrapping]::Wrap
                    $editBox.AcceptsReturn = $true
                    $editBox.Visibility = [System.Windows.Visibility]::Collapsed; $editBox.Tag = $t
                    if ($t.done) { $editBox.IsReadOnly = $true }

                    $displayBlock.Tag = @{ task=$t; editBox=$editBox }
                    $displayBlock.Add_MouseLeftButtonDown({
                        param($sender, $e)
                        try {
                            $data = $sender.Tag
                            if (-not $data.task.done) {
                                $sender.Visibility = [System.Windows.Visibility]::Collapsed
                                $data.editBox.Visibility = [System.Windows.Visibility]::Visible
                                [void]$data.editBox.Focus(); $e.Handled = $true
                            }
                        } catch { Log "!!! displayBlock Click: $_" }
                    })
                    $editBox.Add_LostFocus({
                        param($sender, $e)
                        try {
                            $tsk = $sender.Tag; if ($tsk.done) { return }
                            $raw = $sender.Text.Trim()
                            if ($raw -match "^#(\S+)\s+(?s)(.*)$") { $tsk.category = $matches[1].Trim(); $tsk.text = $matches[2].Trim() }
                            elseif ($raw.Contains("//")) { $parts = $raw.Split([string[]]@("//"), 2, [System.StringSplitOptions]::None); $tsk.category = $parts[0].Trim(); $tsk.text = $parts[1].Trim() }
                            else { $tsk.text = $raw }
                            Save-Data; Render-List
                        } catch { Log "!!! editBox LostFocus: $_" }
                    })

                    [void]$textGrid.Children.Add($displayBlock)
                    [void]$textGrid.Children.Add($editBox)
                    [System.Windows.Controls.Grid]::SetRow($textGrid, 0)
                    [void]$cardGrid.Children.Add($textGrid)

                    if ($t.paths.Count -gt 0) {
                        $attachPanel = New-Object System.Windows.Controls.WrapPanel
                        foreach ($p in $t.paths) {
                            $fileName = [System.IO.Path]::GetFileName($p)
                            $attach = New-Object System.Windows.Controls.TextBlock
                            $attach.Text = "📎 " + $fileName
                            $attach.Foreground = if ($t.done) { Set-SkinColor "#49454F" } else { Set-SkinColor "#8B8B96" }
                            $attach.FontSize = 10 * $s; $attach.Cursor = [System.Windows.Input.Cursors]::Hand
                            $attach.Margin = "0,0,$(6 * $s),$(4 * $s)"
                            $attach.ToolTip = "左键打开 / 右键移除"
                            $attach.Tag = [PSCustomObject]@{ task = $t; path = $p }
                            $attach.Add_MouseEnter({ param($s, $e) $tsk = $s.Tag.task; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#E2B75A" } })
                            $attach.Add_MouseLeave({ param($s, $e) $tsk = $s.Tag.task; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#8B8B96" } })
                            $attach.Add_MouseLeftButtonDown({ param($sender, $e) $e.Handled = $true; try { [System.Diagnostics.Process]::Start($sender.Tag.path) | Out-Null } catch {} })
                            $attach.Add_MouseRightButtonDown({
                                param($sender, $e); $e.Handled = $true
                                try {
                                    $tsk = $sender.Tag.task; $pathToRemove = $sender.Tag.path
                                    $r = [System.Windows.MessageBox]::Show("确定移除此附件吗？", "移除附件", [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Question)
                                    if ($r -eq 'Yes') {
                                        try { Remove-Item -Path $pathToRemove -Force } catch {}
                                        $tsk.paths = @($tsk.paths | Where-Object { $_ -ne $pathToRemove })
                                        Save-Data; Render-List
                                    }
                                } catch { Log "!!! 附件右键: $_" }
                            })
                            [void]$attachPanel.Children.Add($attach)
                        }
                        [System.Windows.Controls.Grid]::SetRow($attachPanel, 1)
                        [void]$cardGrid.Children.Add($attachPanel)
                    }

                    Attach-CustomMenu $card $t
                    Attach-CustomMenu $displayBlock $t
                    $card.Child = $cardGrid
                    [void]$wrap.Children.Add($card)
                }
                [void]$ListContainer.Children.Add($wrap)
            }
            else {
                # list item
                $t = $item.data
                $taskBorder = New-Object System.Windows.Controls.Border
                $taskBorder.Background = Set-SkinColor "#16161A"
                $taskBorder.CornerRadius = 6 * $s; $taskBorder.Margin = "0,0,0,$(6 * $s)"
                $taskBorder.Padding = "$(10 * $s),$(8 * $s)"
                $taskBorder.AllowDrop = $true; $taskBorder.Tag = $t
                $taskBorder.Add_DragEnter({ param($sender, $e) $e.Handled = $true; if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) { $e.Effects = [System.Windows.DragDropEffects]::Copy } })
                $taskBorder.Add_Drop({
                    param($sender, $e); $e.Handled = $true
                    try {
                        if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
                            $files = $e.Data.GetData([System.Windows.DataFormats]::FileDrop)
                            $tsk = $sender.Tag; $tempPaths = @($tsk.paths)
                            foreach ($file in $files) {
                                $fileName = [System.IO.Path]::GetFileName($file)
                                $destPath = Join-Path $global:attachDir $fileName
                                try { Copy-Item -Path $file -Destination $destPath -Force } catch {}
                                if ($tempPaths -notcontains $destPath) { $tempPaths += $destPath }
                            }
                            $tsk.paths = $tempPaths; Save-Data; Render-List
                        }
                    } catch { Log "!!! task Drop: $_" }
                })

                $itemGrid = New-Object System.Windows.Controls.Grid
                [void]$itemGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{Width=[System.Windows.GridLength]::Auto}))
                [void]$itemGrid.ColumnDefinitions.Add((New-Object System.Windows.Controls.ColumnDefinition -Property @{Width=New-Object System.Windows.GridLength(1, [System.Windows.GridUnitType]::Star)}))

                $chk = New-Object System.Windows.Controls.Border
                $chk.Width = 16 * $s; $chk.Height = 16 * $s; $chk.CornerRadius = 8 * $s
                $chk.BorderThickness = 1.5 * $s; $chk.Margin = "0,$(1 * $s),$(10 * $s),0"
                $chk.VerticalAlignment = [System.Windows.VerticalAlignment]::Top
                $chk.Cursor = [System.Windows.Input.Cursors]::Hand; $chk.Tag = $t
                $chk.ToolTip = "左键完成 / 右键置顶"
                if ($t.done) { $chk.Background = Set-SkinColor "#E2B75A"; $chk.BorderBrush = Set-SkinColor "#E2B75A" }
                else { $chk.Background = [System.Windows.Media.Brushes]::Transparent; $chk.BorderBrush = Set-SkinColor "#8B8B96" }
                $chk.Add_MouseLeftButtonDown({ param($s, $e) try { $tsk = $s.Tag; $tsk.done = -not $tsk.done; Save-Data; Render-List } catch { Log "!!! chk left: $_" } })
                $chk.Add_MouseRightButtonDown({
                    param($s, $e)
                    try {
                        $taskToTop = $s.Tag
                        $temp = @($global:TodoData.tasks | Where-Object { $_ -ne $taskToTop })
                        $global:TodoData.tasks = @($taskToTop) + $temp
                        Save-Data; Render-List
                    } catch { Log "!!! chk right: $_" }
                })
                [System.Windows.Controls.Grid]::SetColumn($chk, 0)
                [void]$itemGrid.Children.Add($chk)

                $stack = New-Object System.Windows.Controls.StackPanel
                [System.Windows.Controls.Grid]::SetColumn($stack, 1)
                $textGrid = New-Object System.Windows.Controls.Grid

                $rawText = $t.text; $idx = $rawText.IndexOf("`n")
                if ($idx -ge 0) { $titleText = $rawText.Substring(0, $idx).Trim("`r"); $bodyText = $rawText.Substring($idx + 1) }
                else { $titleText = $rawText; $bodyText = "" }

                $displayBlock = New-Object System.Windows.Controls.TextBlock
                $displayBlock.TextWrapping = [System.Windows.TextWrapping]::Wrap
                $displayBlock.FontSize = 12 * $s
                $displayBlock.Cursor = [System.Windows.Input.Cursors]::IBeam

                $runTitle = New-Object System.Windows.Documents.Run
                $runTitle.Text = $titleText
                $runTitle.Foreground = if ($t.done) { Set-SkinColor "#60606B" } else { Set-SkinColor "#E2B75A" }
                [void]$displayBlock.Inlines.Add($runTitle)
                if ($bodyText) {
                    $runLB = New-Object System.Windows.Documents.Run; $runLB.Text = "`n"
                    [void]$displayBlock.Inlines.Add($runLB)
                    $runBody = New-Object System.Windows.Documents.Run; $runBody.Text = $bodyText
                    $runBody.Foreground = if ($t.done) { Set-SkinColor "#60606B" } else { Set-SkinColor "#EBEBEB" }
                    [void]$displayBlock.Inlines.Add($runBody)
                }

                $editBox = New-Object System.Windows.Controls.TextBox
                $editBox.Text = $t.text; $editBox.Background = [System.Windows.Media.Brushes]::Transparent
                $editBox.BorderThickness = 0; $editBox.Foreground = Set-SkinColor "#EBEBEB"
                $editBox.CaretBrush = Set-SkinColor "#EBEBEB"; $editBox.FontSize = 12 * $s
                $editBox.TextWrapping = [System.Windows.TextWrapping]::Wrap
                $editBox.AcceptsReturn = $true
                $editBox.Visibility = [System.Windows.Visibility]::Collapsed; $editBox.Tag = $t
                if ($t.done) { $editBox.IsReadOnly = $true }

                $displayBlock.Tag = @{ task=$t; editBox=$editBox }
                $displayBlock.Add_MouseLeftButtonDown({
                    param($sender, $e)
                    try {
                        $data = $sender.Tag
                        if (-not $data.task.done) {
                            $sender.Visibility = [System.Windows.Visibility]::Collapsed
                            $data.editBox.Visibility = [System.Windows.Visibility]::Visible
                            [void]$data.editBox.Focus(); $e.Handled = $true
                        }
                    } catch { Log "!!! list displayBlock: $_" }
                })
                $editBox.Add_LostFocus({
                    param($sender, $e)
                    try {
                        $tsk = $sender.Tag; if ($tsk.done) { return }
                        $raw = $sender.Text.Trim()
                        if ($raw -match "^#(\S+)\s+(?s)(.*)$") { $tsk.category = $matches[1].Trim(); $tsk.text = $matches[2].Trim() }
                        elseif ($raw.Contains("//")) { $parts = $raw.Split([string[]]@("//"), 2, [System.StringSplitOptions]::None); $tsk.category = $parts[0].Trim(); $tsk.text = $parts[1].Trim() }
                        else { $tsk.text = $raw }
                        Save-Data; Render-List
                    } catch { Log "!!! list editBox: $_" }
                })

                [void]$textGrid.Children.Add($displayBlock)
                [void]$textGrid.Children.Add($editBox)
                [void]$stack.Children.Add($textGrid)

                if ($null -ne $t.paths -and $t.paths.Count -gt 0) {
                    $attachPanel = New-Object System.Windows.Controls.WrapPanel
                    $attachPanel.Margin = "0,$(6 * $s),0,0"
                    foreach ($p in $t.paths) {
                        $fileName = [System.IO.Path]::GetFileName($p)
                        $attach = New-Object System.Windows.Controls.TextBlock
                        $attach.Text = "📎 " + $fileName
                        $attach.Foreground = if ($t.done) { Set-SkinColor "#49454F" } else { Set-SkinColor "#8B8B96" }
                        $attach.FontSize = 10 * $s; $attach.Cursor = [System.Windows.Input.Cursors]::Hand
                        $attach.Margin = "0,0,$(10 * $s),$(4 * $s)"
                        $attach.ToolTip = "左键打开 / 右键移除"
                        $attach.Tag = [PSCustomObject]@{ task = $t; path = $p }
                        $attach.Add_MouseEnter({ param($s, $e) $tsk = $s.Tag.task; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#E2B75A" } })
                        $attach.Add_MouseLeave({ param($s, $e) $tsk = $s.Tag.task; if(-not $tsk.done){ $s.Foreground = Set-SkinColor "#8B8B96" } })
                        $attach.Add_MouseLeftButtonDown({ param($sender, $e) $e.Handled = $true; try { [System.Diagnostics.Process]::Start($sender.Tag.path) | Out-Null } catch {} })
                        $attach.Add_MouseRightButtonDown({
                            param($sender, $e); $e.Handled = $true
                            try {
                                $tsk = $sender.Tag.task; $pathToRemove = $sender.Tag.path
                                $r = [System.Windows.MessageBox]::Show("确定移除此附件吗？", "移除附件", [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Question)
                                if ($r -eq 'Yes') {
                                    try { Remove-Item -Path $pathToRemove -Force } catch {}
                                    $tsk.paths = @($tsk.paths | Where-Object { $_ -ne $pathToRemove })
                                    Save-Data; Render-List
                                }
                            } catch { Log "!!! 附件右键(list): $_" }
                        })
                        [void]$attachPanel.Children.Add($attach)
                    }
                    [void]$stack.Children.Add($attachPanel)
                }

                Attach-CustomMenu $taskBorder $t
                Attach-CustomMenu $displayBlock $t

                [void]$itemGrid.Children.Add($stack)
                $taskBorder.Child = $itemGrid
                [void]$ListContainer.Children.Add($taskBorder)
            }
        }
        Log "Render-List 完成"
    } catch {
        Log "!!! Render-List 崩溃: $_"
        Log "!!! 堆栈: $($_.ScriptStackTrace)"
    }
}

# ============================================================
# 9. Edge 模式（两态：Dock 常驻竖排标签 + Expanded 展开面板）
# ============================================================

$global:edgeClickedTaskId = $null
$global:lastExpandAt      = [DateTime]::MinValue

$global:edgePalette = @(
    "#45454F","#4A4A55","#3F3F4A","#4F4F5A","#42424C",
    "#484854","#3D3D48","#4C4C58","#464652","#414150"
)

# 分类名 → 稳定的深灰背景色
function Get-CategoryColor([string]$name) {
    if ([string]::IsNullOrWhiteSpace($name) -or $name -eq "无") {
        return "#2B2B36"
    }
    $h = 0
    foreach ($ch in $name.ToCharArray()) { $h = ($h * 31 + [int]$ch) -band 0x7FFFFFFF }
    return $global:edgePalette[$h % $global:edgePalette.Length]
}

function Get-TaskColor($task) {
    try {
        $s = "$($task.id)$($task.category)"
        $h = 0
        foreach ($ch in $s.ToCharArray()) { $h = ($h * 31 + [int]$ch) -band 0x7FFFFFFF }
        return $global:edgePalette[$h % $global:edgePalette.Length]
    } catch { return $global:edgePalette[0] }
}

function Get-EdgeTitleText([string]$raw, [int]$limit = 24) {
    if ([string]::IsNullOrEmpty($raw)) { return "" }
    $idx = $raw.IndexOf("`n")
    if ($idx -ge 0) { $t = $raw.Substring(0, $idx).Trim("`r") } else { $t = $raw }
    $t = $t.Trim()
    if ($t.Length -gt $limit) { $t = $t.Substring(0, $limit) }
    return $t
}

# ★ 用 DIP 单位返回主屏工作区（与 Window.Left/Top 同坐标系）
function Get-PrimaryWorkArea {
    try {
        $r = [System.Windows.SystemParameters]::WorkArea
        Log "WorkArea(DIP): L=$([int]$r.Left) T=$([int]$r.Top) W=$([int]$r.Width) H=$([int]$r.Height)"
        return $r
    } catch {
        Log "!!! SystemParameters.WorkArea 失败: $_"
        return New-Object System.Windows.Rect(0, 0, 1280, 720)
    }
}

function New-EdgeLabelDock($task) {
    $title = Get-EdgeTitleText $task.text 6
    if ([string]::IsNullOrWhiteSpace($title)) { $title = "…" }

    if ($null -eq $global:edgeLabelIdx) { $global:edgeLabelIdx = 0 }
    $myIdx = $global:edgeLabelIdx
    $global:edgeLabelIdx++
    $grays = @(
        "#22222A","#2C2C36","#26262E","#30303A","#282830"
    )
    if ($global:edgeColorPalette) { $grays = $global:edgeColorPalette }
    if ($null -eq $global:edgeLabelIdx) { $global:edgeLabelIdx = 0 }
    $taskBg = $grays[$global:edgeLabelIdx % $grays.Length]
    $global:edgeLabelIdx++

    $label = New-Object System.Windows.Controls.Border
    $label.Background = Get-Color $taskBg
    $label.BorderBrush = Set-SkinColor "#2A2A30"
    $label.BorderThickness = 1
    $label.CornerRadius = 5
    $label.Padding = "4,5,4,5"
    $label.Margin = "0,1,0,1"
    $label.Cursor = [System.Windows.Input.Cursors]::Hand
    $label.Tag = $task
    $label.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
    $label.MinWidth = 28
    if ($task.done) { $label.Opacity = 0.45 }

    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $title
    $tb.FontSize = 11
    $tb.FontWeight = [System.Windows.FontWeights]::Normal
    $lightBg = @("#F5F5F5","#E0E0E0","#9E9E9E")
if ($task.done) {
        $tb.Foreground = Set-SkinColor "#60606B"
    } elseif ($lightBg -contains $taskBg) {
        $tb.Foreground = Set-SkinColor "#1A1A1A"
    } else {
    $tb.Foreground = Set-SkinColor "#FFD700"
    }
    $tb.TextAlignment = [System.Windows.TextAlignment]::Center
    $tb.TextWrapping = [System.Windows.TextWrapping]::NoWrap
    $rot = New-Object System.Windows.Media.RotateTransform(90)
    $tb.LayoutTransform = $rot
    $label.Child = $tb

    $label.Add_MouseEnter({ param($s, $e) if (-not $s.Tag.done) { $s.BorderBrush = Set-SkinColor "#E2B75A" } })
    $label.Add_MouseLeave({ param($s, $e) if (-not $s.Tag.done) { $s.BorderBrush = Set-SkinColor "#2A2A30" } })

    $label.Add_MouseLeftButtonUp({
        param($s, $e)
        try {
            $e.Handled = $true
            $t = $s.Tag
            $global:edgeClickedTaskId = $t.id
            Log "Dock 标签点击: $($t.text)"
            SwitchToEdgeExpanded
        } catch { Log "!!! Dock 标签点击: $_" }
    })

    return $label
}

function New-EdgeContainerDock {
    $global:edgeLabelIdx = 0
    $global:edgeColorPalette = if ($global:TodoData.skin -eq "pastel") { @("#A8C5E8","#E8B5D0","#C5E0B4","#F0D5A8","#D0B5E8","#A8E0DB","#E8C5B4","#B5D0E8","#F0E0A8","#C5D8E8") } else { $null }
    $global:edgeLabelIdx = 0
    $scroll = New-Object System.Windows.Controls.ScrollViewer
    $scroll.VerticalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Hidden
    $scroll.HorizontalScrollBarVisibility = [System.Windows.Controls.ScrollBarVisibility]::Disabled
    $scroll.Background = [System.Windows.Media.Brushes]::Transparent
    $scroll.Padding = "0"

    $stack = New-Object System.Windows.Controls.StackPanel
    $stack.Orientation = [System.Windows.Controls.Orientation]::Vertical
    $stack.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
    $stack.Background = [System.Windows.Media.Brushes]::Transparent

    $active = @($global:TodoData.tasks | Where-Object { $_.done -eq $false })
    $completed = @()
    if ($global:TodoData.showCompleted) {
        $completed = @($global:TodoData.tasks | Where-Object { $_.done -eq $true })
    }

    $activeGroups = $active | Group-Object category | Sort-Object Name

    function New-EdgeDivider {
        $d = New-Object System.Windows.Controls.Border
        $d.Width = 14
        $d.Height = 1
        $d.Background = Set-SkinColor "#E2B75A"
        $d.Opacity = 0.5
        $d.Margin = "0,4,0,4"
        $d.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Center
        return $d
    }

    $first = $true
    foreach ($g in $activeGroups) {
        if (-not $first) { [void]$stack.Children.Add((New-EdgeDivider)) }
        $first = $false
        foreach ($t in $g.Group) {
            try { [void]$stack.Children.Add((New-EdgeLabelDock $t)) }
            catch { Log "!!! New-EdgeLabelDock: $_" }
        }
    }

    if ($completed.Count -gt 0) {
        if (-not $first) { [void]$stack.Children.Add((New-EdgeDivider)) }
        foreach ($t in $completed) {
            try { [void]$stack.Children.Add((New-EdgeLabelDock $t)) }
            catch { Log "!!! New-EdgeLabelDock: $_" }
        }
    }

    if ($activeGroups.Count -eq 0 -and $completed.Count -eq 0) {
        # 无任务：给一个和任务标签同底色、可点的「+」
        # 单击 → 展开成窗框模式并聚焦输入框，可直接打字
        $emptyPalette = @("#22222A","#2C2C36","#26262E","#30303A","#282830")
        if ($global:edgeColorPalette) { $emptyPalette = $global:edgeColorPalette }
        $emptyBg = $emptyPalette[0]

        $plus = New-Object System.Windows.Controls.Border
        $plus.Background = Get-Color $emptyBg
        $plus.BorderBrush = Set-SkinColor "#2A2A30"
        $plus.BorderThickness = 1
        $plus.CornerRadius = 5
        $plus.Padding = "4,7,4,7"
        $plus.Margin = "0,1,0,1"
        $plus.MinWidth = 28
        $plus.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Right
        $plus.Cursor = [System.Windows.Input.Cursors]::Hand
        $plus.ToolTip = "添加任务"

        $plusText = New-Object System.Windows.Controls.TextBlock
        $plusText.Text = "+"
        $plusText.FontSize = 17
        $plusText.FontWeight = [System.Windows.FontWeights]::SemiBold
        $lightBg = @("#F5F5F5","#E0E0E0","#9E9E9E")
        if ($lightBg -contains $emptyBg) {
            $plusText.Foreground = Set-SkinColor "#1A1A1A"
        } else {
            $plusText.Foreground = Set-SkinColor "#E2B75A"
        }
        $plusText.TextAlignment = [System.Windows.TextAlignment]::Center
        $plus.Child = $plusText

        $plus.Add_MouseEnter({ param($s, $e) $s.BorderBrush = Set-SkinColor "#E2B75A" })
        $plus.Add_MouseLeave({ param($s, $e) $s.BorderBrush = Set-SkinColor "#2A2A30" })

        $plus.Add_MouseLeftButtonUp({
            param($s, $e)
            try {
                $e.Handled = $true
                Log "Dock 空状态「+」点击 -> 展开"
                $global:edgeClickedTaskId = $null
                SwitchToEdgeExpanded
                try {
                    $window.Activate()
                    if ($script:InputTask) {
                        [void]$script:InputTask.Focus()
                        [void][System.Windows.Input.Keyboard]::Focus($script:InputTask)
                    }
                } catch {
                    Log "!!! 聚焦输入框: $_"
                }
            } catch {
                Log "!!! 空状态「+」点击: $_"
            }
        })

        [void]$stack.Children.Add($plus)
    }

    $scroll.Content = $stack
    return $scroll
}

# ---------- Dock 态：常驻竖排标签，高度按任务数自适应 ----------
function SwitchToEdgeDock {
    param([switch]$Force)
    # 锁已禁用（防止拦截 Enter-EdgeMode）
    if ($Force) { $global:edgeExpandedLocked = $false }
    if ($global:switching) { return }
    $global:switching = $true
    try {
        Log "-> SwitchToEdgeDock"
        $global:edgeState = "dock"

        $window.MinWidth = 20
        $window.MinHeight = 60

        $wa  = Get-PrimaryWorkArea
        $waT = [double]$wa.Top
        $waH = [double]$wa.Height
        $waR = [double]$wa.Left + [double]$wa.Width
        $waB = $waT + $waH

        $count = @($global:TodoData.tasks).Count
        if ($count -lt 1) { $count = 1 }

        # 每个标签约占 46px 视觉高度；总高度最多屏幕 80%
        $perItem = 46
        $maxH = [Math]::Min($waH - 100, $waH * 0.8)
        $targetH = $count * $perItem + 16
        if ($targetH -gt $maxH) { $targetH = $maxH }
        if ($targetH -lt 80) { $targetH = 80 }

        # 紧凑宽度：只比标签略宽
        $targetW = 52

        $window.Width = $targetW
        $window.Height = $targetH
        $window.Left = $waR - $targetW - 6

        # 位置：屏幕偏上 20%
        $top = $waT + $waH * 0.2
        if ($top + $targetH -gt $waB - 20) { $top = $waB - $targetH - 20 }
        if ($top -lt $waT + 20) { $top = $waT + 20 }
        $window.Top = $top

        $window.Visibility = [System.Windows.Visibility]::Visible
        $window.Topmost = $true

        $window.Content = $null
        $window.Content = New-EdgeContainerDock
        $window.UpdateLayout()

        Log "Dock 完成: W=$targetW H=$targetH L=$($window.Left) T=$($window.Top) 任务数=$count"
    } catch {
        Log "!!! SwitchToEdgeDock: $_"
        Log "!!! 堆栈: $($_.ScriptStackTrace)"
    } finally {
        $global:switching = $false
    }
}

# ---------- Expanded 态：完整面板 ----------
function SwitchToEdgeExpanded {
    if ($global:switching) { return }
    $global:switching = $true
    try {
        Log "-> SwitchToEdgeExpanded"
        $global:edgeState = "expanded"
        $global:edgeExpandedLocked = $true
        $global:lastExpandAt = [DateTime]::Now

        $wa  = Get-PrimaryWorkArea
        $waT = [double]$wa.Top
        $waW = [double]$wa.Width
        $waH = [double]$wa.Height
        $waR = [double]$wa.Left + $waW

        $w = 380
        $h = 520
        if ($h -gt $waH - 40) { $h = $waH - 40 }
        if ($w -gt $waW - 40) { $w = $waW - 40 }

        $window.MinWidth = 250
        $window.MinHeight = 250

        $window.Width = $w
        $window.Height = $h
        $window.Left = $waR - $w - 2

        $targetTop = $waT + ($waH - $h) / 2
        if ($targetTop -lt $waT + 10) { $targetTop = $waT + 10 }
        $window.Top = $targetTop

        $window.Content = $null
        $window.Content = $global:mainContent
        Render-List

        Log "Expanded 完成: W=$w H=$h L=$($window.Left) T=$($window.Top)"
    } catch {
        Log "!!! SwitchToEdgeExpanded: $_"
        Log "!!! 堆栈: $($_.ScriptStackTrace)"
    } finally {
        $global:switching = $false
    }
}

function Enter-EdgeMode {
    Log "Enter-EdgeMode: 进入"
    $global:TodoData.viewMode = "edge"
    if ($global:edgeState -eq "normal") {
        try { $global:TodoData.x = $window.Left; $global:TodoData.y = $window.Top } catch {}
        try { $global:TodoData.w = $window.Width; $global:TodoData.h = $window.Height } catch {}
    }
    SwitchToEdgeDock -Force
    Save-Data
    Log "Enter-EdgeMode: 完成"
}

function Exit-EdgeMode {
    Log "Exit-EdgeMode: 进入. edgeState=$($global:edgeState)"
    if ($global:edgeState -ne "normal") {
        $global:switching = $true
        try {
            $global:edgeState = "normal"
            $window.MinWidth = 250
            $window.MinHeight = 250
            $window.Content = $null
            $window.Content = $global:mainContent
            try { $window.Width  = [double]$global:TodoData.w } catch { $window.Width = 360 }
            try { $window.Height = [double]$global:TodoData.h } catch { $window.Height = 500 }
            try { $window.Left   = [double]$global:TodoData.x } catch { $window.Left = 200 }
            try { $window.Top    = [double]$global:TodoData.y } catch { $window.Top = 150 }
        } catch {
            Log "!!! Exit-EdgeMode: $_"
        } finally {
            $global:switching = $false
        }
    }
    Log "Exit-EdgeMode: 完成"
}

# ---------- 鼠标离开 Expanded → 回 Dock（0.8s 延迟） ----------
# 轮询检测鼠标是否离开 Expanded 窗口 → 自动收回 Dock
$hoverWatchTimer = New-Object System.Windows.Threading.DispatcherTimer
$hoverWatchTimer.Interval = [TimeSpan]::FromMilliseconds(400)
$hoverWatchTimer.Add_Tick({
    # 完全禁用：不自动收起，请按 ESC 或切模式
})
# DISABLED-hover: $hoverWatchTimer.Start()
# 前台窗口轮询（Deactivated 在无边框 Topmost 窗口上不可靠，改用轮询）
if (-not ('Win32Foreground' -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Foreground {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
}
"@
}

$foregroundWatch = New-Object System.Windows.Threading.DispatcherTimer
$foregroundWatch.Interval = [TimeSpan]::FromMilliseconds(600)
$foregroundWatch.Add_Tick({
    try {
        if ($global:switching) { return }
        if ($global:TodoData.viewMode -ne "edge") { return }
        if ($global:edgeState -ne "expanded") { return }
        if ($window.IsMouseOver) { return }
        $fg = [Win32Foreground]::GetForegroundWindow()
        $myHwnd = (New-Object System.Windows.Interop.WindowInteropHelper($window)).Handle
        if ($fg -ne $myHwnd) {
            Log "前台窗口非自己 -> 收起 Dock"
            SwitchToEdgeDock -Force
        }
    } catch { }
})
$foregroundWatch.Start()
$edgeCollapseTimer = New-Object System.Windows.Threading.DispatcherTimer
$edgeCollapseTimer.Interval = [TimeSpan]::FromMilliseconds(800)
$edgeCollapseTimer.Add_Tick({
    try {
        $edgeCollapseTimer.Stop()
        if ($global:switching) { return }
        if ($global:TodoData.viewMode -ne "edge") { return }
        if ($global:edgeState -ne "expanded") { return }
        if ($window.IsMouseOver) { return }
        if ($InputTask -and $InputTask.IsKeyboardFocused) { return }
        Log "收起定时器 -> Dock"
        SwitchToEdgeDock
    } catch { Log "!!! 收起定时器: $_" }
})

# ESC 键收起 Expanded
$window.Add_KeyDown({
    param($s, $e)
    try {
        if ($e.Key -eq [System.Windows.Input.Key]::Escape) {
            if ($global:TodoData.viewMode -eq "edge" -and $global:edgeState -eq "expanded") {
                SwitchToEdgeDock -Force
                $e.Handled = $true
            }
        }
    } catch {}
})

# 鼠标在窗口内移动 → 重置收起计时器
$window.Add_MouseMove({
    param($s, $e)
    try {
        if ($global:TodoData.viewMode -eq "edge" -and $global:edgeState -eq "expanded") {
            $global:lastExpandAt = [DateTime]::Now
        }
    } catch {}
})
$window.Add_MouseLeave({
    param($s, $e)
    try {
        if ($global:switching) { return }
        if ($global:TodoData.viewMode -ne "edge") { return }
        if ($global:edgeState -ne "expanded") { return }
        # 自动收起已禁用
        $edgeCollapseTimer.Stop()
        # DISABLED-collapse: $edgeCollapseTimer.Start()
    } catch { Log "!!! MouseLeave: $_" }
})

# ============================================================
# 10. 窗口基础事件
# ============================================================

$BtnPin.Add_Click({ param($sender, $e); Toggle-Topmost })

$DragBar.Add_MouseLeftButtonDown({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        $window.DragMove()
    } catch { Log "DragMove: $_" }
})

$window.Add_LocationChanged({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        if ($window.WindowState -eq 'Normal') { $global:TodoData.x = $window.Left; $global:TodoData.y = $window.Top }
    } catch {}
})

$window.Add_SizeChanged({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        if ($window.WindowState -eq 'Normal') { $global:TodoData.w = $window.Width; $global:TodoData.h = $window.Height }
    } catch {}
})

$deactivateCheck = New-Object System.Windows.Threading.DispatcherTimer
$deactivateCheck.Interval = [TimeSpan]::FromMilliseconds(400)
$deactivateCheck.Add_Tick({
    $deactivateCheck.Stop()
    try {
        if ($global:switching) { return }
        if ($global:TodoData.viewMode -ne "edge") { return }
        if ($global:edgeState -ne "expanded") { return }
        if ($window.IsActive) { return }
        if ($window.IsMouseOver) { return }
        Log "失焦 -> 收起 Dock"
        SwitchToEdgeDock -Force
    } catch { Log "!!! Deactivated 检查: $_" }
})

$window.Add_Deactivated({ param($sender, $e); Save-Data; try { $deactivateCheck.Stop(); $deactivateCheck.Start() } catch {} })
$BtnClose.Add_Click({
    param($sender, $e)
    try { Save-Data; $window.Hide() } catch { Log "!!! BtnClose: $_" }
})
$window.Add_Closed({ param($sender, $e); Save-Data; Log "窗口已关闭" })

$InputTask.Add_GotFocus({ param($sender, $e) try { if ($sender.Text -eq $placeholderText) { $sender.Text = ""; $sender.Foreground = Set-SkinColor "#EBEBEB" } } catch {} })
$InputTask.Add_LostFocus({ param($sender, $e) try { if ($sender.Text.Trim() -eq "") { $sender.Text = $placeholderText; $sender.Foreground = Set-SkinColor "#B0B0BA" } } catch {} })

$InputTask.Add_PreviewKeyDown({
    param($sender, $e)
    try {
        if ($e.Key -eq [System.Windows.Input.Key]::Enter) {
            if ([System.Windows.Input.Keyboard]::Modifiers.HasFlag([System.Windows.Input.ModifierKeys]::Shift)) { return }
            $e.Handled = $true
            $raw = $sender.Text.Trim()
            if ($raw -ne "" -and $raw -ne $placeholderText) {
                $cat = "无"; $txt = $raw
                if ($raw -match "^#(\S+)\s+(?s)(.*)$") { $cat = $matches[1].Trim(); $txt = $matches[2].Trim() }
                elseif ($raw.Contains("//")) { $parts = $raw.Split([string[]]@("//"), 2, [System.StringSplitOptions]::None); $cat = $parts[0].Trim(); $txt = $parts[1].Trim() }
                $newTask = [PSCustomObject]@{ id = [guid]::NewGuid().ToString(); text = $txt; done = $false; category = $cat; paths = @() }
                $global:TodoData.tasks = @($global:TodoData.tasks) + $newTask
                $sender.Text = ""; Save-Data; Render-List
                Log "新增任务: $txt"
            }
        }
    } catch { Log "!!! 输入框 Enter: $_" }
})

$mainBorder.Add_DragEnter({ param($sender, $e) if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) { $e.Effects = [System.Windows.DragDropEffects]::Copy } })
$mainBorder.Add_Drop({
    param($sender, $e)
    try {
        if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
            $files = $e.Data.GetData([System.Windows.DataFormats]::FileDrop)
            $tempArray = @($global:TodoData.tasks)
            foreach ($file in $files) {
                $fileName = [System.IO.Path]::GetFileName($file)
                $destPath = Join-Path $global:attachDir $fileName
                try { Copy-Item -Path $file -Destination $destPath -Force } catch {}
                $nameWithoutExt = [System.IO.Path]::GetFileNameWithoutExtension($file)
                $newTask = [PSCustomObject]@{ id = [guid]::NewGuid().ToString(); text = $nameWithoutExt; done = $false; category = "00 附件关联"; paths = @($destPath) }
                $tempArray += $newTask
            }
            $global:TodoData.tasks = $tempArray; Save-Data; Render-List
            Log "拖入 $($files.Count) 个文件"
        }
    } catch { Log "!!! 主面板 Drop: $_" }
})

# ============================================================
# 11. 顶层按钮事件
# ============================================================
$BtnView.Add_Click({
    param($sender, $e)
    try {
        Log "BtnView 点击. 当前 viewMode=$($global:TodoData.viewMode)"
        switch ($global:TodoData.viewMode) {
            "grid" { $global:TodoData.viewMode = "list" }
            "list" { $global:TodoData.viewMode = "edge" }
            "edge" { $global:TodoData.viewMode = "grid" }
            default { $global:TodoData.viewMode = "grid" }
        }
        $menuEdgeModeItem.Checked = ($global:TodoData.viewMode -eq "edge")
        switch ($global:TodoData.viewMode) {
            "grid" { $BtnView.Content = "≣"; Exit-EdgeMode; Render-List }
            "list" { $BtnView.Content = "⊞"; Exit-EdgeMode; Render-List }
            "edge" { $BtnView.Content = "◧"; Enter-EdgeMode }
        }
        Save-Data
    } catch {
        Log "!!! BtnView 失败: $_"
        Log "!!! 堆栈: $($_.ScriptStackTrace)"
        $global:TodoData.viewMode = "grid"
        $BtnView.Content = "≣"
        $menuEdgeModeItem.Checked = $false
        try { Exit-EdgeMode } catch {}
        try { Render-List } catch {}
    }
})

$BtnPin.Add_Click({ param($sender, $e); Toggle-Topmost })

$DragBar.Add_MouseLeftButtonDown({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        $window.DragMove()
    } catch { Log "DragMove: $_" }
})

$window.Add_LocationChanged({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        if ($window.WindowState -eq 'Normal') { $global:TodoData.x = $window.Left; $global:TodoData.y = $window.Top }
    } catch {}
})

$window.Add_SizeChanged({
    param($sender, $e)
    try {
        if ($global:edgeState -ne "normal") { return }
        if ($window.WindowState -eq 'Normal') { $global:TodoData.w = $window.Width; $global:TodoData.h = $window.Height }
    } catch {}
})

$window.Add_Deactivated({ param($sender, $e); Save-Data })
$BtnClose.Add_Click({
    param($sender, $e)
    try { Save-Data; $window.Hide() } catch { Log "!!! BtnClose: $_" }
})
$window.Add_Closed({ param($sender, $e); Save-Data; Log "窗口已关闭" })

$InputTask.Add_GotFocus({ param($sender, $e) try { if ($sender.Text -eq $placeholderText) { $sender.Text = ""; $sender.Foreground = Set-SkinColor "#EBEBEB" } } catch {} })
$InputTask.Add_LostFocus({ param($sender, $e) try { if ($sender.Text.Trim() -eq "") { $sender.Text = $placeholderText; $sender.Foreground = Set-SkinColor "#B0B0BA" } } catch {} })

$InputTask.Add_PreviewKeyDown({
    param($sender, $e)
    try {
        if ($e.Key -eq [System.Windows.Input.Key]::Enter) {
            if ([System.Windows.Input.Keyboard]::Modifiers.HasFlag([System.Windows.Input.ModifierKeys]::Shift)) { return }
            $e.Handled = $true
            $raw = $sender.Text.Trim()
            if ($raw -ne "" -and $raw -ne $placeholderText) {
                $cat = "无"; $txt = $raw
                if ($raw -match "^#(\S+)\s+(?s)(.*)$") { $cat = $matches[1].Trim(); $txt = $matches[2].Trim() }
                elseif ($raw.Contains("//")) { $parts = $raw.Split([string[]]@("//"), 2, [System.StringSplitOptions]::None); $cat = $parts[0].Trim(); $txt = $parts[1].Trim() }
                $newTask = [PSCustomObject]@{ id = [guid]::NewGuid().ToString(); text = $txt; done = $false; category = $cat; paths = @() }
                $global:TodoData.tasks = @($global:TodoData.tasks) + $newTask
                $sender.Text = ""; Save-Data; Render-List
                Log "新增任务: $txt"
            }
        }
    } catch { Log "!!! 输入框 Enter: $_" }
})

$mainBorder.Add_DragEnter({ param($sender, $e) if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) { $e.Effects = [System.Windows.DragDropEffects]::Copy } })
$mainBorder.Add_Drop({
    param($sender, $e)
    try {
        if ($e.Data.GetDataPresent([System.Windows.DataFormats]::FileDrop)) {
            $files = $e.Data.GetData([System.Windows.DataFormats]::FileDrop)
            $tempArray = @($global:TodoData.tasks)
            foreach ($file in $files) {
                $fileName = [System.IO.Path]::GetFileName($file)
                $destPath = Join-Path $global:attachDir $fileName
                try { Copy-Item -Path $file -Destination $destPath -Force } catch {}
                $nameWithoutExt = [System.IO.Path]::GetFileNameWithoutExtension($file)
                $newTask = [PSCustomObject]@{ id = [guid]::NewGuid().ToString(); text = $nameWithoutExt; done = $false; category = "00 附件关联"; paths = @($destPath) }
                $tempArray += $newTask
            }
            $global:TodoData.tasks = $tempArray; Save-Data; Render-List
            Log "拖入 $($files.Count) 个文件"
        }
    } catch { Log "!!! 主面板 Drop: $_" }
})

# ============================================================
# 12. 初始渲染 & 启动
# ============================================================
Log "初始 Render-List"
Render-List

Log "进入 ShowDialog 前的状态: viewMode=$($global:TodoData.viewMode)"

# 启动时恢复上次 viewMode
$savedMode = $global:TodoData.viewMode
if ($savedMode -notin @("grid","list","edge")) { $savedMode = "grid" }
$menuEdgeModeItem.Checked = ($savedMode -eq "edge")
switch ($savedMode) {
    "grid" { $BtnView.Content = "≣" }
    "list" { $BtnView.Content = "⊞" }
    "edge" { $BtnView.Content = "◧" }
}
Log "启动恢复 viewMode=$savedMode"

$global:initialEnterDone = $false
$window.Add_ContentRendered({
    param($s, $e)
    try {
        Log "ContentRendered 触发"
        if ($global:initialEnterDone) { return }
        $global:initialEnterDone = $true
        if ($global:TodoData.viewMode -eq "edge") { Enter-EdgeMode }
    } catch { Log "!!! 启动恢复失败: $_" }
})

try {
    Log ">>> ShowDialog 开始 <<<"
    $window.ShowDialog() | Out-Null
    Log ">>> ShowDialog 结束 <<<"
} catch {
    Log "!!! ShowDialog 抛出异常: $_"
    Log "!!! 堆栈: $($_.ScriptStackTrace)"
} finally {
    Log "脚本退出"
}
