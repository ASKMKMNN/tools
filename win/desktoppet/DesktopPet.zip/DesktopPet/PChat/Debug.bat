@echo off
chcp 65001
echo 正在启动 PChat 终极调试模式...
powershell.exe -STA -ExecutionPolicy Bypass -File .\Chat.ps1
echo.
echo ========================================
echo 进程已结束！请截图上面的【红字报错信息】发给我！
pause