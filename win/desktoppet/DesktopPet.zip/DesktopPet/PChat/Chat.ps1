﻿Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms

# ==========================================
# 0. 智能路径与跨模块通讯定位
# ==========================================
# 兼容 PChat 放在子文件夹或直接放在根目录的情况
if ((Split-Path $PSScriptRoot -Leaf) -eq "PChat") {
    $ProjectRoot = Split-Path $PSScriptRoot -Parent
} else {
    $ProjectRoot = $PSScriptRoot
}
# 定位到躯体的数据核心
$CoreDir = Join-Path $ProjectRoot "Core"

# ==========================================
# 1. 涅槃重生引擎 (PID 留在 PChat 自己家)
# ==========================================
$PidFile = Join-Path $PSScriptRoot "PChat.pid"
if (Test-Path $PidFile) {
    $oldPid = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($oldPid -match '^\d+$' -and $oldPid -ne $PID) {
        Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
    }
}
$PID | Out-File $PidFile -Encoding UTF8

# ==========================================
# 2. 核心配置区（在这里可以自由调整默认大小）
# ==========================================
$Script:DefaultWidth = 280   # 默认启动宽度（原 360，已缩小）
$Script:DefaultHeight = 300  # 默认启动高度（原 420，已大大缩矮）
$Script:MinWidth = 240       # 允许拖拽缩小的最小宽度
$Script:MinHeight = 150      # 允许拖拽缩小的最小高度

$Script:OffsetX = 5      
$Script:OffsetY = -5     
$Script:TailHeight = 90

# 自己的文件留在自己目录下
$Script:HistoryFile = Join-Path $PSScriptRoot "ChatHistory.json"
$Script:ApiConfigFile = Join-Path $PSScriptRoot "API.txt"

# 跨模块读取宠物的配置文件
$PetFile = Join-Path $CoreDir "dpet.json"

# QuickNav 矩阵 (保留你独立的工程路径)
$Script:QuickNavFolder = (Join-Path $env:USERPROFILE 'Documents\Y_App\QuickNav\folder')
$Script:QuickNavHTA = (Join-Path $env:USERPROFILE 'Documents\Y_App\QuickNav\QuickNav2.hta')

# API 动态读取
$Script:ModelName = "qwen-vl-plus"
$Script:ApiKey = "token-xxxxxxxx"
$Script:ApiUrl = "http://xxxxx/chat/completions"

if (Test-Path $Script:ApiConfigFile) {
    $apiLines = Get-Content $Script:ApiConfigFile -Encoding UTF8
    foreach ($line in $apiLines) {
        if ($line -match 'model:\s*(.+)$') { $Script:ModelName = $Matches[1].Trim().Trim("'", '"') }
        if ($line -match 'apiKey:\s*(.+)$') { $Script:ApiKey = $Matches[1].Trim().Trim("'", '"') }
        if ($line -match 'apiBase:\s*(.+)$') { 
            $base = $Matches[1].Trim().Trim("'", '"')
            if ($base -notmatch '/chat/completions$') { $base = $base.TrimEnd('/') + "/chat/completions" }
            $Script:ApiUrl = $base 
        }
    }
}

$Script:QuickNavDict = @{}
if (Test-Path $Script:QuickNavFolder) {
    foreach ($file in Get-ChildItem -Path $Script:QuickNavFolder -File) {
        $parts = $file.BaseName -split "=", 2
        if ($parts.Count -eq 2) { 
            foreach ($alias in ($parts[0] -split ",")) { $Script:QuickNavDict[$alias.Trim().ToLower()] = $file.FullName } 
        }
    }
}

# ==========================================
# 3. 动态人设提取 (跨界读取 dpet.json)
# ==========================================
$Script:PetName = "桌面助手"      
$Script:DisplayName = "桌面助手"  

if (Test-Path $PetFile) { 
    try { 
        # 强制 UTF-8 读取防止乱码
        $jsonStr = [System.IO.File]::ReadAllText($PetFile, [System.Text.Encoding]::UTF8)
        $p = $jsonStr | ConvertFrom-Json
        $fullName = ""
        if ($null -ne $p.ImagePath) { $fullName = [System.IO.Path]::GetFileNameWithoutExtension($p.ImagePath) }
        
        if (-not [string]::IsNullOrWhiteSpace($fullName)) {
            $Script:PetName = $fullName 
            if ($fullName -match "-") { $Script:DisplayName = ($fullName -split "-", 2)[0].Trim() } 
            else { $Script:DisplayName = $fullName }
        }
    } catch { } 
}

# ==========================================
# 4. UI 界面设计 (已动态绑定核心配置区的宽高)
# ==========================================
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PChat_UI_Instance" 
        Height="$Script:DefaultHeight" Width="$Script:DefaultWidth" 
        MinWidth="$Script:MinWidth" MinHeight="$Script:MinHeight"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        ShowInTaskbar="False" Topmost="True">
    <Grid Margin="10">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="*"/>
            <ColumnDefinition Width="15"/>
        </Grid.ColumnDefinitions>
        
        <Border Grid.Column="0" Background="#DD1E1E1E" CornerRadius="15" Padding="15">
            <Border.Effect>
                <DropShadowEffect Color="Black" BlurRadius="15" Opacity="0.6"/>
            </Border.Effect>
            <Grid>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="*"/>
                    <RowDefinition Height="10"/>
                    <RowDefinition Height="Auto"/>
                </Grid.RowDefinitions>
                
                <Grid x:Name="TopBar" Grid.Row="0" Margin="0,0,0,10" Background="Transparent">
                    <Button x:Name="HistoryBtn" Content="🕒 历史" Background="Transparent" Foreground="#AAAAAA" BorderThickness="0" FontSize="12" HorizontalAlignment="Left" Cursor="Hand"/>
                    <TextBlock Text="🐾 PChat" Foreground="#888888" FontSize="11" HorizontalAlignment="Center" VerticalAlignment="Center" IsHitTestVisible="False"/>
                    <Button x:Name="CloseBtn" Content="✕" Background="Transparent" Foreground="#888888" BorderThickness="0" FontSize="14" HorizontalAlignment="Right" Cursor="Hand"/>
                </Grid>
                
                <RichTextBox x:Name="ChatHistory" Grid.Row="1" IsReadOnly="True" Background="Transparent" BorderThickness="0" VerticalScrollBarVisibility="Hidden">
                    <FlowDocument x:Name="ChatDoc" PagePadding="5" FontFamily="Microsoft YaHei" FontSize="14"/>
                </RichTextBox>
                
                <Grid Grid.Row="3">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="60"/>
                    </Grid.ColumnDefinitions>
                    
                    <Border Grid.Column="0" Background="#2D2D2D" BorderBrush="#BFBFBF" BorderThickness="1.5" CornerRadius="15">
                        <TextBox x:Name="InputBox" Background="Transparent" Foreground="White" BorderThickness="0" VerticalContentAlignment="Center" FontSize="14" Padding="10,0" CaretBrush="White" AcceptsReturn="True"/>
                    </Border>
                    
                    <Border Grid.Column="1" Background="#007ACC" CornerRadius="15" Margin="8,0,0,0">
                        <Button x:Name="SendBtn" Content="发送" Background="Transparent" Foreground="White" BorderThickness="0" Cursor="Hand"/>
                    </Border>
                </Grid>
            </Grid>
        </Border>
        
        <Path Grid.Column="1" Fill="#DD1E1E1E" Data="M 0,0 L 15,10 L 0,20 Z" VerticalAlignment="Bottom" Margin="-1,0,0,$($Script:TailHeight)"/>
        
        <Thumb x:Name="ResizeNW" Width="20" Height="20" HorizontalAlignment="Left" VerticalAlignment="Top" Cursor="SizeNWSE">
            <Thumb.Template>
                <ControlTemplate>
                    <Border Background="Transparent"/>
                </ControlTemplate>
            </Thumb.Template>
        </Thumb>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader -ArgumentList $xaml
$Window = [Windows.Markup.XamlReader]::Load($reader)

$ChatDoc = $Window.FindName("ChatDoc")
$InputBox = $Window.FindName("InputBox")
$SendBtn = $Window.FindName("SendBtn")
$ChatHistory = $Window.FindName("ChatHistory")
$CloseBtn = $Window.FindName("CloseBtn")
$HistoryBtn = $Window.FindName("HistoryBtn")
$ResizeNW = $Window.FindName("ResizeNW")
$TopBar = $Window.FindName("TopBar")

if (Test-Path $PetFile) { 
    try { 
        $jsonStr = [System.IO.File]::ReadAllText($PetFile, [System.Text.Encoding]::UTF8)
        $p = $jsonStr | ConvertFrom-Json
        $Window.WindowStartupLocation = "Manual"
        
        $petLeft = $p.Left
        if ($null -eq $petLeft) { 
            $petW = if ($null -ne $p.ActualWidth) { $p.ActualWidth } else { $p.LimitSize }
            $petLeft = $p.Right - $petW 
        }
        
        $Window.Left = $petLeft - $Window.Width + $Script:OffsetX
        $Window.Top = $p.Bottom - $Window.Height + $Script:OffsetY 
    } catch { 
        $Window.WindowStartupLocation = "CenterScreen" 
    } 
}

$ResizeNW.Add_DragDelta({ 
    $newW = $Window.Width - $_.HorizontalChange
    $newH = $Window.Height - $_.VerticalChange
    if ($newW -ge $Script:MinWidth) { $Window.Left += $_.HorizontalChange; $Window.Width = $newW }
    if ($newH -ge $Script:MinHeight) { $Window.Top += $_.VerticalChange; $Window.Height = $newH } 
})

$TopBar.Add_MouseLeftButtonDown({ param($sender, $e) if ($e.ClickCount -eq 2) { $Window.Close() } })
$CloseBtn.Add_Click({ $Window.Close() })
$Window.Add_MouseLeftButtonDown({ $Window.DragMove() })
$Window.Add_Loaded({ $InputBox.Focus() | Out-Null })

# ==========================================
# 5. Markdown 渲染引擎 
# ==========================================
function Parse-Markdown ($markdown) {
    $sect = New-Object System.Windows.Documents.Section
    $sect.Foreground = [System.Windows.Media.Brushes]::WhiteSmoke
    $lines = $markdown -split "`n"
    $inCode = $false
    $inTable = $false
    $codePara = $null
    $inlineRegex = '(\*\*.*?\*\*|\*.*?\*|_[^_]+_|\x60.*?\x60)'
    
    foreach ($line in $lines) {
        $line = $line.Trim("`r")
        
        if ($line -like "```*") { 
            if ($inCode) { 
                $inCode = $false
                $sect.Blocks.Add($codePara) 
            } else { 
                $inCode = $true
                $codePara = New-Object System.Windows.Documents.Paragraph
                $codePara.Background = [System.Windows.Media.Brushes]::DarkSlateGray
                $codePara.Foreground = [System.Windows.Media.Brushes]::LightGray
                $codePara.FontFamily = New-Object System.Windows.Media.FontFamily -ArgumentList "Consolas"
                $codePara.Padding = New-Object System.Windows.Thickness -ArgumentList 8
                $codePara.Margin = New-Object System.Windows.Thickness -ArgumentList 0,2,0,2 
            }
            continue 
        }
        
        if ($inCode) { 
            $run = New-Object System.Windows.Documents.Run
            $run.Text = "$line`n"
            $codePara.Inlines.Add($run)
            continue 
        }
        
        if ($line -match "\|") {
            if (-not $inTable) { 
                $inTable = $true
                $table = New-Object System.Windows.Documents.Table
                $table.CellSpacing = 0
                $table.BorderBrush = [System.Windows.Media.Brushes]::Gray
                $table.BorderThickness = New-Object System.Windows.Thickness -ArgumentList 1
                $table.Margin = New-Object System.Windows.Thickness -ArgumentList 0,2,0,2
                $rg = New-Object System.Windows.Documents.TableRowGroup
                $table.RowGroups.Add($rg)
                $sect.Blocks.Add($table) 
            }
            if ($line -match '^[\s\|\-\:\.]+$') { continue }
            
            $tr = New-Object System.Windows.Documents.TableRow
            $cells = ($line.Trim() -replace '^\|', '' -replace '\|$', '') -split '\|'
            foreach ($c in $cells) { 
                $tc = New-Object System.Windows.Documents.TableCell
                $tc.BorderBrush = [System.Windows.Media.Brushes]::Gray
                $tc.BorderThickness = New-Object System.Windows.Thickness -ArgumentList 1
                $tc.Padding = New-Object System.Windows.Thickness -ArgumentList 4
                $p = New-Object System.Windows.Documents.Paragraph
                $p.Margin = New-Object System.Windows.Thickness -ArgumentList 0,0,0,0
                $parts = $c.Trim() -split $inlineRegex
                foreach ($part in $parts) { 
                    if ([string]::IsNullOrEmpty($part)) { continue }
                    $r = New-Object System.Windows.Documents.Run
                    if ($part -match '^\*\*(.*)\*\*$') { $r.Text = $Matches[1]; $r.FontWeight = [System.Windows.FontWeights]::Bold; $r.Foreground = [System.Windows.Media.Brushes]::White }
                    elseif ($part -match '^\*(.*)\*$' -or $part -match '^_(.*)_$') { $r.Text = $Matches[1]; $r.FontStyle = [System.Windows.FontStyles]::Italic; $r.Foreground = [System.Windows.Media.Brushes]::LightGray }
                    elseif ($part -match '^\x60(.*)\x60$') { $r.Text = $Matches[1]; $r.FontFamily = New-Object System.Windows.Media.FontFamily -ArgumentList "Consolas"; $r.Foreground = [System.Windows.Media.Brushes]::LightSkyBlue }
                    else { $r.Text = $part }
                    $p.Inlines.Add($r) 
                }
                $tc.Blocks.Add($p)
                $tr.Cells.Add($tc) 
            }
            $rg.Rows.Add($tr)
            continue
        } else { $inTable = $false }
        
        $p = New-Object System.Windows.Documents.Paragraph
        $p.Margin = New-Object System.Windows.Thickness -ArgumentList 0,0,0,0
        if ($line -match "^(#{1,6})\s+(.*)") { $line = $Matches[2]; $p.FontWeight = [System.Windows.FontWeights]::Bold; $p.Foreground = [System.Windows.Media.Brushes]::LightSkyBlue; $p.Margin = New-Object System.Windows.Thickness -ArgumentList 0,8,0,2 }
        elseif ($line -match "^>\s?(.*)") { $line = $Matches[1]; $p.Foreground = [System.Windows.Media.Brushes]::DarkGray; $p.BorderBrush = [System.Windows.Media.Brushes]::Gray; $p.BorderThickness = New-Object System.Windows.Thickness -ArgumentList 4,0,0,0; $p.Padding = New-Object System.Windows.Thickness -ArgumentList 10,0,0,0 }
        elseif ($line -match "^(---|___|\*\*\*)\s*$") { $p.Margin = New-Object System.Windows.Thickness -ArgumentList 0,2,0,4; $p.BorderBrush = [System.Windows.Media.Brushes]::DimGray; $p.BorderThickness = New-Object System.Windows.Thickness -ArgumentList 0,1,0,0; $p.FontSize = 1; $line = "" }
        elseif ($line -match "^[\*\-]\s+(.*)") { $line = "• " + $Matches[1]; $p.Margin = New-Object System.Windows.Thickness -ArgumentList 15,0,0,0 }
        elseif ($line -match "^(\d+\.)\s+(.*)") { $line = $Matches[1] + " " + $Matches[2]; $p.Margin = New-Object System.Windows.Thickness -ArgumentList 15,0,0,0 }
        
        $parts = $line -split $inlineRegex
        foreach ($part in $parts) { 
            if ([string]::IsNullOrEmpty($part)) { continue }
            $r = New-Object System.Windows.Documents.Run
            if ($part -match '^\*\*(.*)\*\*$') { $r.Text = $Matches[1]; $r.FontWeight = [System.Windows.FontWeights]::Bold; $r.Foreground = [System.Windows.Media.Brushes]::White }
            elseif ($part -match '^\*(.*)\*$' -or $part -match '^_(.*)_$') { $r.Text = $Matches[1]; $r.FontStyle = [System.Windows.FontStyles]::Italic; $r.Foreground = [System.Windows.Media.Brushes]::LightGray }
            elseif ($part -match '^\x60(.*)\x60$') { $r.Text = $Matches[1]; $r.FontFamily = New-Object System.Windows.Media.FontFamily -ArgumentList "Consolas"; $r.Foreground = [System.Windows.Media.Brushes]::LightSkyBlue }
            else { $r.Text = $part }
            $p.Inlines.Add($r) 
        }
        $sect.Blocks.Add($p)
    }
    return $sect
}

# ==========================================
# 6. 提示词与发送逻辑
# ==========================================
$CurrentDate = Get-Date -Format 'yyyy年MM月dd日 dddd'
$SystemPromptContent = @"
【最高指令】：你首先是一个极其专业、精准、能够解答复杂技术问题的 AI 助手。
【当前外观设定】：【$($Script:PetName)】。
【回答规则】：
1. 绝对不能因为“该角色不懂技术”就拒绝回答或装傻。遇到技术问题时，你必须给出极其专业、准确的解答，但要使用该角色的语气、口癖或动作描写来进行包装。
2. 严禁在文末加“——名字”这种生硬落款，要把性格自然融入对话。
3. 日常闲聊必须简短（2句以内），技术科普可以适当详细并使用 Markdown 表格/代码块。
当前日期：$CurrentDate
"@

$Script:Messages = @(@{ role = "system"; content = $SystemPromptContent })
$BrushConv = New-Object System.Windows.Media.BrushConverter

function Append-Block ($speaker, $text, $colorHex, $isFinal) {
    $para = New-Object System.Windows.Documents.Paragraph -Property @{Margin="0,8,0,2"}
    $runS = New-Object System.Windows.Documents.Run -Property @{Text="【$speaker】";Foreground=$BrushConv.ConvertFromString($colorHex);FontWeight="Bold"}
    $para.Inlines.Add($runS)
    
    if ($isFinal) { 
        $ChatDoc.Blocks.Add($para)
        $ChatDoc.Blocks.Add((Parse-Markdown $text)) 
    } else { 
        $runT = New-Object System.Windows.Documents.Run -Property @{Text="`n" + $text;Foreground="#EFEFEF"}
        $para.Inlines.Add($runT)
        $ChatDoc.Blocks.Add($para)
        return $runT 
    }
}

function Send-Message {
    $rawInput = $InputBox.Text
    $txt = $rawInput.Trim()
    
    if ([string]::IsNullOrWhiteSpace($txt)) { return }
    $InputBox.Text = ""
    $SendBtn.IsEnabled = $false
    
    # ==========================================
    # 链接识别：纯链接（含 /svn/ 路径）交给系统默认程序打开
    # ==========================================
    $isLink = ($txt -notmatch '\s') -and ($txt -match '/svn/' -or $txt -match '^(https?://|svn://)')
    if ($isLink) {
        try {
            Start-Process $txt
            $null = Append-Block "你" "[已用默认程序打开]`n$txt" "#569CD6" $true
            $Window.Close(); return
        } catch {
            $null = Append-Block $Script:DisplayName "（打开链接失败）" "#888888" $true
        }
    }

    # ==========================================
    # 原有的普通路径与网址识别
    # ==========================================
    $firstWord = ($txt -split '\s+')[0]
    $isPath = ($txt -match '^(https?://|www\.|\\\\|[a-zA-Z]:[\\/])') -or (($txt.StartsWith("/") -or $txt.StartsWith("\")) -and ($firstWord.Substring(1) -match '[/\\]'))
    
    if ($isPath) { 
        $url = if ($txt.StartsWith("www.")) { "https://" + $txt } else { $txt }
        $null = Append-Block "你" $txt "#569CD6" $true
        try { Start-Process $url; $Window.Close(); return } catch { $null = Append-Block $Script:DisplayName "（打开失败）" "#888888" $true }
        $SendBtn.IsEnabled = $true
        return 
    }

    $isCmd = $false; $cmdLine = ""
    if ($txt.StartsWith("/")) { $isCmd = $true; $cmdLine = $txt.Substring(1).Trim() } 
    elseif ($rawInput -match "(?s)^[ \u3000]{2,}(.*)") { $isCmd = $true; $cmdLine = $Matches[1].Trim() }

    if ($isCmd) {
        if ($cmdLine -match "(?s)^(t|fy)\s+(.*)") { 
            $rawText = $Matches[2].Trim()
            $null = Append-Block "你" "[请求翻译]`n$rawText" "#569CD6" $true
            $activeRun = Append-Block $Script:DisplayName "（翻译中...）" "#888888" $false
            [System.Windows.Forms.Application]::DoEvents()
            $txt = "请将以下内容自动翻译成汉语、日语和英语，三段显示。并对其中外语的重点词和语法用汉语加以解释。内容：`n" + $rawText 
        } else {
            $parts = $cmdLine -split '\s+', 2
            $key = $parts[0].ToLower()
            $arg = if ($parts.Count -gt 1) { $parts[1] } else { "" }
            $escArg = if ($arg) { [uri]::EscapeDataString($arg) } else { "" }
            $hnd = $false
            
            if ($Script:QuickNavDict.ContainsKey($key)) { 
                $tgt = $Script:QuickNavDict[$key]
                $hnd = $true
                try { 
                    if ($tgt.EndsWith("=")) { Start-Process "$tgt$escArg" } 
                    elseif ($arg) { Start-Process $tgt -ArgumentList $arg } 
                    else { Start-Process $tgt }
                    $Window.Close(); return 
                } catch { $null = Append-Block $Script:DisplayName "（指令执行失败）" "#888888" $true } 
            } elseif (Test-Path $Script:QuickNavHTA) { 
                $hnd = $true
                try { Start-Process "mshta.exe" -ArgumentList """$Script:QuickNavHTA"" $cmdLine"; $Window.Close(); return } catch { } 
            }
            if (-not $hnd) { $null = Append-Block $Script:DisplayName "（未知指令）" "#888888" $true }
            $SendBtn.IsEnabled = $true
            $ChatHistory.ScrollToEnd()
            return
        }
    } else { 
        $null = Append-Block "你" $txt "#569CD6" $true
        $ChatHistory.ScrollToEnd()
        $activeRun = Append-Block $Script:DisplayName "" "#E5A445" $false 
        $ChatHistory.ScrollToEnd()
    }

    $Script:Messages += @{ role = "user"; content = $txt }
    try {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
        $req = [System.Net.WebRequest]::Create($Script:ApiUrl)
        $req.Method = "POST"
        $req.ContentType = "application/json"
        $req.Headers.Add("Authorization", "Bearer $Script:ApiKey")
        
        $body = @{ model = $Script:ModelName; messages = $Script:Messages; stream = $true } | ConvertTo-Json -Depth 10 -Compress
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $strm = $req.GetRequestStream()
        $strm.Write($bytes, 0, $bytes.Length)
        $strm.Close()
        
        $asyncResult = $req.BeginGetResponse($null, $null)
        while (-not $asyncResult.IsCompleted) { [System.Threading.Thread]::Sleep(30); [System.Windows.Forms.Application]::DoEvents() }
        
        $reader = New-Object System.IO.StreamReader($req.EndGetResponse($asyncResult).GetResponseStream(), [System.Text.Encoding]::UTF8)
        $fullReply = ""
        
        while (-not $reader.EndOfStream) { 
            $line = $reader.ReadLine()
            if ($line -match 'data: (\{.*\})') { 
                $delta = ($Matches[1] | ConvertFrom-Json).choices[0].delta.content
                if ($delta) { $fullReply += $delta; $activeRun.Text += $delta; [System.Windows.Forms.Application]::DoEvents() } 
            } 
        }
        
        $Script:Messages += @{ role = "assistant"; content = $fullReply }
        $ChatDoc.Blocks.Remove($activeRun.Parent)
        $null = Append-Block $Script:DisplayName $fullReply "#E5A445" $true
        
        try { @{ Messages = $Script:Messages } | ConvertTo-Json -Depth 10 | Set-Content $Script:HistoryFile -Encoding UTF8 } catch {}
    } catch { $activeRun.Text += "`n[连接中断]" } 
    finally { $SendBtn.IsEnabled = $true; $InputBox.Focus() | Out-Null }
}

function Load-History {
    if (Test-Path $Script:HistoryFile) { 
        try { 
            $hData = Get-Content $Script:HistoryFile -Encoding UTF8 -Raw | ConvertFrom-Json
            $ChatDoc.Blocks.Clear()
            $Script:Messages = @($Script:Messages[0])
            
            foreach ($m in $hData.Messages) { 
                if ($m.role -eq "user") { $null = Append-Block "你" $m.content "#569CD6" $true } 
                elseif ($m.role -eq "assistant") { $null = Append-Block $Script:DisplayName $m.content "#E5A445" $true }
                if ($m.role -ne "system") { $Script:Messages += @{ role = $m.role; content = $m.content } } 
            } 
        } catch {} 
    }
    $InputBox.Focus() | Out-Null; $ChatHistory.ScrollToEnd()
}

$HistoryBtn.Add_Click({ Load-History })
$Window.Add_PreviewKeyDown({ param($s, $e) if ($e.Key -eq "Escape") { $e.Handled = $true; $Window.Close() } })
$InputBox.Add_PreviewKeyDown({ 
    param($s, $e) 
    if ($e.Key -eq "Enter" -and [System.Windows.Input.Keyboard]::Modifiers -ne "Shift") { $e.Handled = $true; Send-Message } 
    elseif ($e.Key -eq "Tab") { $e.Handled = $true; $HistoryBtn.RaiseEvent((New-Object System.Windows.RoutedEventArgs([System.Windows.Controls.Button]::ClickEvent))) } 
    elseif ($e.Key -eq "Up") { try { if ($InputBox.GetLineIndexFromCharacterIndex($InputBox.CaretIndex) -eq 0) { $e.Handled=$true; $InputBox.CaretIndex=0 } } catch {} } 
    elseif ($e.Key -eq "Down") { try { if ($InputBox.GetLineIndexFromCharacterIndex($InputBox.CaretIndex) -eq ($InputBox.LineCount-1)) { $e.Handled=$true; $InputBox.CaretIndex=$InputBox.Text.Length } } catch {} } 
})

$null = Append-Block $Script:DisplayName "（就绪）" "#888888" $true
$Window.ShowDialog() | Out-Null