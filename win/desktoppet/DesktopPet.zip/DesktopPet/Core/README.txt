Core 目录说明

Assets\      角色图（gif / png / jpg），随机轮播
Actions\     单击 / 双击 / 三击 触发的动作文件，每个子目录放一个
dpet.json    位置、大小、速度等状态，首次运行后自动生成
TempDocs\    点击动作可打开的本地临时文档

加图：把文件丢进 Assets\ 即可，重启桌宠后生效。
